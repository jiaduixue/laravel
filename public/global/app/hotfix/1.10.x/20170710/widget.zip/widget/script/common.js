/*! Lazy Load 1.9.7 - MIT license - Copyright 2010-2015 Mika Tuupola */
!function(a,b,c,d){var e=a(b);a.fn.lazyload=function(f){function g(){var b=0;i.each(function(){var c=a(this);if(!j.skip_invisible||c.is(":visible"))if(a.abovethetop(this,j)||a.leftofbegin(this,j));else if(a.belowthefold(this,j)||a.rightoffold(this,j)){if(++b>j.failure_limit)return!1}else c.trigger("appear"),b=0})}var h,i=this,j={threshold:0,failure_limit:0,event:"scroll",effect:"show",container:b,data_attribute:"original",skip_invisible:!1,appear:null,load:null,placeholder:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"};return f&&(d!==f.failurelimit&&(f.failure_limit=f.failurelimit,delete f.failurelimit),d!==f.effectspeed&&(f.effect_speed=f.effectspeed,delete f.effectspeed),a.extend(j,f)),h=j.container===d||j.container===b?e:a(j.container),0===j.event.indexOf("scroll")&&h.bind(j.event,function(){return g()}),this.each(function(){var b=this,c=a(b);b.loaded=!1,(c.attr("src")===d||c.attr("src")===!1)&&c.is("img")&&c.attr("src",j.placeholder),c.one("appear",function(){if(!this.loaded){if(j.appear){var d=i.length;j.appear.call(b,d,j)}a("<img />").bind("load",function(){var d=c.attr("data-"+j.data_attribute);c.hide(),c.is("img")?c.attr("src",d):c.css("background-image","url('"+d+"')"),c[j.effect](j.effect_speed),b.loaded=!0;var e=a.grep(i,function(a){return!a.loaded});if(i=a(e),j.load){var f=i.length;j.load.call(b,f,j)}}).attr("src",c.attr("data-"+j.data_attribute))}}),0!==j.event.indexOf("scroll")&&c.bind(j.event,function(){b.loaded||c.trigger("appear")})}),e.bind("resize",function(){g()}),/(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion)&&e.bind("pageshow",function(b){b.originalEvent&&b.originalEvent.persisted&&i.each(function(){a(this).trigger("appear")})}),a(c).ready(function(){g()}),this},a.belowthefold=function(c,f){var g;return g=f.container===d||f.container===b?(b.innerHeight?b.innerHeight:e.height())+e.scrollTop():a(f.container).offset().top+a(f.container).height(),g<=a(c).offset().top-f.threshold},a.rightoffold=function(c,f){var g;return g=f.container===d||f.container===b?e.width()+e.scrollLeft():a(f.container).offset().left+a(f.container).width(),g<=a(c).offset().left-f.threshold},a.abovethetop=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollTop():a(f.container).offset().top,g>=a(c).offset().top+f.threshold+a(c).height()},a.leftofbegin=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollLeft():a(f.container).offset().left,g>=a(c).offset().left+f.threshold+a(c).width()},a.inviewport=function(b,c){return!(a.rightoffold(b,c)||a.leftofbegin(b,c)||a.belowthefold(b,c)||a.abovethetop(b,c))},a.extend(a.expr[":"],{"below-the-fold":function(b){return a.belowthefold(b,{threshold:0})},"above-the-top":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-screen":function(b){return a.rightoffold(b,{threshold:0})},"left-of-screen":function(b){return!a.rightoffold(b,{threshold:0})},"in-viewport":function(b){return a.inviewport(b,{threshold:0})},"above-the-fold":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-fold":function(b){return a.rightoffold(b,{threshold:0})},"left-of-fold":function(b){return!a.rightoffold(b,{threshold:0})}})}(jQuery,window,document);

//lazyload
function imgLoad(){
	var option = {
		threshold: 100,
		load:function(){
			var obj = $(this);
			obj.attr("data-lazyload",false);
			if(obj.parent().parent().hasClass('mui-grid-9')){
				var _img = new Image();
				_img.src = obj.attr("data-original");
				_img.onload = function(){
					var imgW = _img.width,
						imgH = _img.height;
					if(imgW>=imgH){
						obj.css("background-size","auto 100%");	
					}else{
						obj.css({"background-size":"100% auto"});	
					}	
				}
				
			}
			if(obj.parent().parent().parent('#divReviewImage').length>0){
				imgWH(this);
			}
			if(typeof(obj.attr('data-autowh'))!='undefined'){
				var _img = new Image();
				_img.src = obj.attr("data-original");
				_img.onload = function(){
					var imgW = _img.width,
						imgH = _img.height;
					if(imgW>=imgH){
						obj.css("background-size","auto 100%");	
					}else{
						obj.css({"background-size":"100% auto"});	
					}	
				}
			}
			
		}
	}
	jQuery("[data-lazyload=true]").lazyload(option);
}

function getCId(){
	var localUinfo = localStorage.getItem("OURMALL_USERINFO");
	localUinfo = localUinfo ? JSON.parse(localUinfo) : "";
	if(localUinfo && localUinfo.customerId){
		return localUinfo.customerId;
	}else{
		return "";
	}
}
function getUserInfo(callback, force) {
	force = force ? force : false;
	var userDataString = '';
	var userData = null;
	var nowTimestamp = Date.parse(new Date()) / 1000;
	var lastCheckTimestamp = localStorage.getItem("LAST_CHECK_TIMESTAMP") ? localStorage.getItem("LAST_CHECK_TIMESTAMP") : 0;
	var validLoginDay = 1;
	if(userDataString = localStorage.getItem("OURMALL_USERINFO")) {
		userData = JSON.parse(userDataString);
		if(lastCheckTimestamp == 0 && userData.timeLogin) {
			lastCheckTimestamp = Date.parse(new Date(userData.timeLogin.replace(/-/g, "/"))) / 1000;
		}
	}
	if(nowTimestamp - lastCheckTimestamp >= 86400 * validLoginDay) {
		//登录超过 validLoginDay 天，主动从app退出登录，重新检查登录信息
		userData = null;
		localStorage.removeItem('OURMALL_USERINFO');
	}
	if(userData && (!force)) {
		//如果有本地登录信息，直接返回
		$api.rmStorage('LAST_PAGE_BEFORE_LOGIN');
		if(typeof(callback) == 'string'){
			if(callback) {
				eval(callback);
			} else {
				return true;
			}
		} else {
			callback(userData);
		}
	} else {
		localStorage.setItem("LAST_CHECK_TIMESTAMP", nowTimestamp);
		var UILoading = api.require('UILoading');
		var loadingId;
		if(callback) {
			UILoading.flower({
			    center: {
			        x: api.winWidth / 2.0,
					y: api.winHeight / 2.0
			    },
			    size: 40,
			    fixed: true
			}, function(ret) {
			    loadingId = ret;
			});
		}
		var type = 0;
		if(api.systemType == 'ios') {
			type = 2;
		} else {
			type = 1;
		}
		$.mamall_request('member.getmemberbyuids', {
			mPlatform: type,
			jpushCode: localStorage.getItem("OURMALL_RGID"),
			OM_DEVICE_UUID: api.deviceId,
			H5_API_REQUEST_CACHE_SET: 2
		}, function(r) {
			if(loadingId) {
				UILoading.closeFlower(loadingId);
			}
			if('9999' == r.ErrorCode) {
				var userData = r.Data.Customer;
				if(userData.customerId){
					$api.rmStorage('LAST_PAGE_BEFORE_LOGIN');
					localStorage.setItem("OURMALL_USERINFO",JSON.stringify(userData));
					if(typeof(callback) == 'string'){
						if(callback) {
							eval(callback);
						} else {
							return true;
						}
					} else {
						callback(userData);
					}
				}else{
					if(callback != '') {
						api.openWin({
							name: "login",
							url: "widget://html/account/login.html",
							animation: {
								type: "movein",
								subType: "from_right"
							},
							reload: true
						});
					} else {
						return false;
					}
				}
			}
		},"",api);
	}
	return false;
}

function goCart(){
	api.execScript({
	    name: 'main',
	    script: 'changeFrame(document.getElementById("AppMenuCart"), 2, true);'
	});
	api.openWin({
    	name: 'main',
    	slidBackEnabled:false,
    	animation:{
	    	type:'none'
	    }
	});
	setTimeout(function(){ api.closeWin({}) }, 200);
}
function scrollToTop(){
	$('html, body').animate({scrollTop:0}, 200);
}
function formatNumber(num) {
	num = String(num).split(".");
	num[0] = (num[0] || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
	if(num[1]){
		num = num[0]+'.'+num[1];
	}else{
		num = num[0]
	}
    
	return num
}
function formatNumberAsForeigner(num, point) {
	point = point ? point : 0;
	var str = parseFloat(num) + '';
	var len = str.length;
	var newNumberStr = 0;
	if(len <= 3) {
	    newNumberStr = str;
	} else if (len <= 6) {
	    point = str.substr(len-3, point);
	    newNumberStr = str.substr(0, len-3) + (point ? '.' + point : '') + 'K';
	} else if (len <= 9) {
	    point = str.substr(len-6, point);
	    newNumberStr = str.substr(0, len-6) + (point ? '.' + point : '') + 'M';
	} else if (len <= 12) {
	    point = str.substr(len-9, point);
	    newNumberStr = str.substr(0, len-9) + (point ? '.' + point : '') + 'G';
	} else{
	    point = str.substr(len-12, point);
	    newNumberStr = str.substr(0, len-12) + (point ? '.' + point : '') + 'T';
	}
	return newNumberStr;
}


function cartReady(){
	$.mamall_request('video.cart.check', {
		OM_DEVICE_UUID: api.deviceId
	}, function(r) {
		if('9999' == r.ErrorCode) {
			if(r.Data){
				$api.setStorage("cart",'true');
			}else{
				$api.setStorage("cart","false");
			}
			setTimeout(function(){
				cartActive($api.getStorage("cart"));
			},100);
		}
	},"",api);
	
	api.addEventListener({
	    name: 'cartListener'
	}, function(ret, err) {
		cartActive(ret.value.Key); 
	});
	
}
function cartActive(on){
	if(on==="true"){
		$(".nui-header-item .icon-gouwuche").addClass("active");
		$(".bottom-button-group [data-type='cart']").addClass("active");
	}else{
		$(".nui-header-item .icon-gouwuche").removeClass("active");
		$(".bottom-button-group [data-type='cart']").removeClass("active");
	}
}
//rate app
function showThisVerRate() {
	//生成评分交互
	var rateFlag = localStorage.getItem("HAS_RATE_ALREADY");
	if((! rateFlag) && getCId()) {
		var lastTimeCheckRate = localStorage.getItem("LAST_TIME_CHECK_RATE");
		var d = new Date();
		var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(lastTimeCheckRate && lastTimeCheckRate != today) {
			//不是当天下载的新用户
			var thisVerCloseFlag = localStorage.getItem("RATE_CLOSED_VER_" + api.appVersion);
			if((! thisVerCloseFlag)) {
				//找到页面元素，显示html评分提示
			}
		}
		if(lastTimeCheckRate == null) {
			localStorage.setItem("LAST_TIME_CHECK_RATE", today);
		}
	}
}
function hideThisVerRate(rated) {
	//本版本不再显示或者已经评过分，隐藏当前提示评分模块
	//隐藏html
	/*
	hide dom
	*/

	//当前版本不再显示提醒
	localStorage.setItem("RATE_CLOSED_VER_" + api.appVersion, true);
	//所有版本不再显示提醒
	if(rated == true) {
		//已前去打过分，不再显示打分模块
		localStorage.setItem("HAS_RATE_ALREADY", true);
	}
}
function ratingReturn(type){
 	switch(type){
 		case 'notreally':
 			$(".rating-box p").text($.i18n.prop("Would you mind giving us some feedback?"));
 			$(".rating-box .action a").not(".confirm").text($.i18n.prop("No, thanks.")).prop('href','javascript:ratingReturn("no");');
 			$(".rating-box .action a.confirm").text($.i18n.prop("Ok,sure")).prop('href','javascript:ratingReturn("feedback");');
 			break;
 		case 'yes':
 			$(".rating-box p").text($.i18n.prop("How about a rating on the App Store,then?"));
 			$(".rating-box .action a").not(".confirm").text($.i18n.prop("No, thanks.")).prop('href','javascript:ratingReturn("no");');
 			$(".rating-box .action a.confirm").text($.i18n.prop("Ok,sure")).prop('href','javascript:ratingReturn("rating");');
 			break;
 		case 'feedback':
 			$(".rating-box p").text('Feedback');
 			$(".rating-box .action").hide().after('<div class="fb-box">\
														<textarea placeholder="' + $.i18n.prop("Please help us perfect service for you") + '"></textarea>\
														<div class="fb-action">\
															<a href="javascript:ratingRemove();" tapmode>' + $.i18n.prop("Cancel") + '</a>\
															<a href="javascript:feedbackSubmit();" class="confirm" tapmode>' + $.i18n.prop("Submit") + '</a>\
														</div>\
													</div>');
 			break;
 		case 'rating':
 			var rateUrl = '';
 			if(api.systemType == 'ios') {
 				rateUrl = 'https://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=1133962714&pageNumber=0&sortOrdering=2&type=Purple+Software&mt=8';
 			} else {
 				rateUrl = 'market://details?id=com.ourmall';
 			}
   			window.location.href = rateUrl;
			localStorage.setItem("HAS_RATE_ALREADY", true);
 			ratingRemove();
 			break;	
 		case 'no':
 			ratingRemove();
 			break;	
 	}
}
function ratingCreat(_tagName){
	//生成评分交互
	var ratingBox = '';
	var rateFlag = localStorage.getItem("HAS_RATE_ALREADY");
	if((! rateFlag) && getCId()) {
		var lastTimeCheckRate = localStorage.getItem("LAST_TIME_CHECK_RATE");
		var d = new Date();
		var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(lastTimeCheckRate && lastTimeCheckRate != today) {
			//不是当天下载的新用户
			var thisVerCloseFlag = localStorage.getItem("RATE_CLOSED_VER_" + api.appVersion);
			if((! thisVerCloseFlag)) {
				//当前版本没有点过关闭评分提示
				if(!_tagName){
			 		_tagName = 'section';
			 	}
			 	//创建提示
			 	ratingBox = '<'+_tagName+' data-box="rating">\
								<div class="rating-box">\
									<p>' + $.i18n.prop("Enjoying OurMall App?") + '</p>\
									<div class="action">\
										<a href="javascript:ratingReturn(\'notreally\');">' + $.i18n.prop("Not really") + '</a>\
										<a class="confirm" href="javascript:ratingReturn(\'yes\');">' + $.i18n.prop("Yes") + '!</a>\
									</div>\
								</div>\
							</'+_tagName+'>';
			}
		}
		if(lastTimeCheckRate == null) {
			//新用户，第一次监测，把监测日期设置为今天
			localStorage.setItem("LAST_TIME_CHECK_RATE", today);
		}
	}
	return ratingBox;
}
function ratingRemove(){
 	//提示框消失
 	localStorage.setItem("RATE_CLOSED_VER_" + api.appVersion, true);//当前版本不再提醒
	$(".rating-box").parent().fadeOut(200);
	setTimeout(function(){
		$(".rating-box").remove();
	},200);
}
function feedbackSubmit(){
 	var text = $(".rating-box textarea").val();
 	if(text!=""){
 		$.mamall_request('feedback.insert', {
			customerId: getCId(),
			content:text
		}, function(r) {
			nui.toast($.i18n.prop("Thank you for your feedback!"));
			localStorage.setItem("HAS_RATE_ALREADY", true);
			ratingRemove();
		},"",api);
 	}else{
		nui.toast($.i18n.prop("Please text something..."));
 	}
}
function gotoOurMallWeb(url, name) {
	name = name ? name : '';
	if(sysType == 'ios') {
		var type = 2;
	} else {
		var type = 1;
	}
	var sysType = api.systemType;
	var jpId = localStorage.getItem("OURMALL_RGID")?localStorage.getItem("OURMALL_RGID"):"";
	if(! getCId()) {
		$api.setStorage('LAST_PAGE_BEFORE_LOGIN', {type:'OurMallWeb', name:name, url:url});
	}
	var redirectUrl = hostURL() + "?m=main&a=redirectFromApp&hideH5Menu=1&hideH5MenuFromNewApp=1&mPlatform=" + type + "&jpushCode=" + jpId + "&OM_DEVICE_UUID=" + api.deviceId;
	url = redirectUrl + '&redirectUrl=' + encodeURIComponent(url);
	api.openWin({
		name: "OurMallWeb_" + name.replace(/ /g, '_'),// + '_' + Math.random(),
		url: "widget://html/product/webpage.html",
		pageParam: {_url:url,name:name},//这里是要打开的网址
		animation: {
			type: "movein",
			subType: "from_right"
		},
		reload: true,
		slidBackEnabled: false
	});
}
function hostURL(){
    var host = '';
    var HTTP_HEADER = '';
    if(api.debug == true) {
        HTTP_HEADER = 'http';
		host = HTTP_HEADER + '://sandbox.video.ourmall.com/index.php';
    }else{
		HTTP_HEADER = 'https';
		host = HTTP_HEADER + '://video.ourmall.com/index.php';
	}
    return host;
}
function openFrameReload(index,type){
	if(!type){
		type = "mall"	
	}
	api.setFrameGroupIndex({
		name: type+'Group',
		index: index,
		scroll: true,
		reload:true	
	});
}
//pay success
function paySuccess(type,name,productData,gid){
	api.execScript({
		name: 'my-orders',
		script:'api.closeFrameGroup({name: "my-orders-group"})'
	});
	if(name == 'undefined' && type == 'true'){
//		api.openWin({
//				name:'my-orders',
//				url : 'widget://html/account/my-orders.html',
//					animation: {
//						type: "movein",
//						subType: "from_right"
//					},
//				reload:true,	
//				pageParam:{
//					status:0
//				}
//		});
		
		api.openWin({
			name:'groupbuying-successfully',
			url : 'widget://html/cart/groupbuying-successfully.html',
			animation: {
				type: "movein",
				subType: "from_right"
			},
			reload:true,	
			pageParam:{
				data:productData,
				gid:gid
			}
		});
	
		
	}else{
		api.openWin({
			name:'my-orders',
			url : 'widget://html/account/my-orders.html',
				animation: {
					type: "movein",
					subType: "from_right"
				},
			reload:true,	
			pageParam:{
				status:0
			}
		});
	}
	
	
	setTimeout(function(){
		api.execScript({
			name:'my-orders',
			script:'statausBAR()'
		});
	},1200);	
	setTimeout(function(){
		if(type != 'true'){
			api.execScript({
				name:'main',
				script:'changeFrame(document.getElementById("AppMenuCart"), 2, true);'
			})
		}
		api.closeWin({
		    name: 'order-confirm',
		    animation:{
		    	type:'none'
		    }
		});
		api.closeWin({
		    name: 'order-detail',
		    animation:{
		    	type:'none'
		    }
		});
		api.closeWin({
		    name: 'groupbuying-detail-platform',
		    animation:{
		    	type:'none'
		    }
		});
		
	},700);		
}
function startPaypal(totalPrice,paymentOrderCode,type,name,productDat,gid){
	var paypal = api.require('paypal');
	if(typeof payMask != 'function'){
		payMask = function(){
			api.execScript({
			    name: 'main',
			    script: 'paySuccess("' + type + '","' + name + '",' + productDat +',"' + gid + '")'
			});	
		}
	}
	paypal.pay({
	     currency: 'USD',
	     price: totalPrice,
	     description: 'OurMall Order:' + paymentOrderCode,
	     mode: api.debug == true ? 'sandbox' : 'production' // production  sandbox  noNetwork
	}, function(ret) {
	 	if(ret && ret.state == 'success') {
	 	    $.mamall_request('video.order.executepayment',{paymentId:ret.response.id, type:1, orderCode:paymentOrderCode}, function(r) {
	 			if('9999' == r.ErrorCode) {
	 				//日志
					var logJson = new Object;
					logJson.orderId = paymentOrderCode.split(",");
					appLog(7,logJson);
					
	 				payMask('success');
				} else {
	 				payMask('failed');
	 			}
				setTimeout(function(){
	 					api.execScript({
						    name: 'main',
						    script: 'paySuccess("' + type + '","' + name + '",' + productDat +',"' + gid + '")'
						});	
	 				},3250);
	 		},undefined,api);
	 	}else{
	 		payMask('failed');
	 		setTimeout(function(){
					api.execScript({
				    name: 'main',
				    script: 'paySuccess("' + type + '","payFailed")'
				});	
			},2000);
	 	}
    });
}

function startPayssion(customerId,paymentData){
	var jsonOrderCodeData = new Object; 
	var paymentData2 = new Object;
	for(var i in paymentData){
		jsonOrderCodeData[i] = new Object;
	}
	for (var j in jsonOrderCodeData){
		jsonOrderCodeData[j].goodsAmount = paymentData[j].goodsAmount
		jsonOrderCodeData[j].shippingAmount = paymentData[j].shippingAmount
		jsonOrderCodeData[j].couponAmount = paymentData[j].couponAmount
	}
	paymentData2.customerId = customerId;
	paymentData2.jsonOrderCode = JSON.stringify(jsonOrderCodeData)
	
	$.mamall_request('order.getpayurl',paymentData2, function(r) {
		if(r.ErrorCode == '9999') {
			var pay2Url = r.Data.payUrl;
			api.openWin({
				name: "payssion",
				url: "widget://html/product/webpage.html",
				pageParam: {_url:pay2Url,name:'Pay Order'},//这里是要打开的网址
				animation: {
					type: "movein",
					subType: "from_right"
				},
				reload: true,
				slidBackEnabled: false
			});
		} else {
			nui.toast(r.Message);
			api.sendEvent({
			    name: 'cancelPay'
			});
		}
	},undefined,api);
}
function startCash( customerId,paymentOrderCode,type,name,productDat,gid)
{
	$.mamall_request('order.pay', {
		customerId:customerId,
		codeStr:paymentOrderCode,
	}, function(r) {
		if (r.Data.status == true) {
			payMask('success');
		}else
		{
			payMask('failed');
		}
		setTimeout(function(){
			api.execScript({
				name: 'main',
				script: 'paySuccess("' + type + '","' + name + '",' + productDat +',"' + gid + '")'
			});
		},3250);
	},undefined,api)
}
function cardPayReturn(type,msg){
	switch(type){
		case 'success':
			payMask('success');
			setTimeout(function(){
				api.execScript({
				    name: 'main',
				    script: 'paySuccess()'
				});	
			},3250);		
		break;
		case 'failed':
			payMask('failed',msg.trim() ? msg.trim() : 'Failed');
		    setTimeout(function(){
				api.execScript({
				    name: 'main',
				    script: 'paySuccess()'
				});	
			},2000);
		break;
	}
}
//打开二维码
function openQrCodeByStr(str){
	api.openFrame({
		name: 'str-to-qrcode',
		url: 'widget://html/main/str-to-qrcode.html',
		bounces: false,
		bgColor: 'rgba(0,0,0,.7)',
		pageParam: {
			str:str,
		},
		vScrollBarEnabled: false,
		hScrollBarEnabled: false,
		reload: true
	});
}
function startCouponPop(customerId){
	var _switch = true,
		status;
	var popOption = new Object;
	popOption.customerId = customerId;
	popOption.couponType = 1;//新人礼包
	// //app是否领过优惠券
	// var couponStatus = $api.getStorage('GET_FIRST_COUPON_STATUS') == 'true' ? true : false;
	// if(couponStatus) return;
	
	$.mamall_request('coupon.hasget', popOption, function(r) {
    	if (r.ErrorCode == '9999'){
    		_switch = r.Data.hasCoupon;
    		status = r.Data.status;
    		if(!_switch){
    			api.openFrame({
					name: 'pop-coupon-mask',
					url: 'widget://html/pop/pop-coupon-mask.html',
					bounces: false,
					bgColor: 'rgba(0,0,0,.7)',
					vScrollBarEnabled: false,
					hScrollBarEnabled: false,
					pageParam: {
						first: status == 'new' ? '1':''
					}
				});
    		} else {
    			$api.setStorage('GET_FIRST_COUPON_STATUS', 'true');
    			api.alert({
					msg: $.i18n.prop("You have aleady got the coupons, enjoy shopping!"),
				}, function(ret, err) {
					api.closeFrame({
						name: 'pop-coupon-mask'
					});
				});
    		}
    	}
    }, undefined, api);
}
function closeCouponPop() {
	api.execScript({
		name:'main',
		frameName:'pop-coupon-mask',
		script:"api.closeFrame({name: 'pop-coupon-mask'});"
	});
	api.execScript({
		name:'main',
		frameName:'pop-fans-coupon-mask',
		script:"api.closeFrame({name: 'pop-fans-coupon-mask'});"
	});
	api.execScript({
		name:'pro-detail-platform',
		frameName:'pop-fans-coupon-mask',
		script:"api.closeFrame({name: 'pop-fans-coupon-mask'});"
	});
	$api.rmStorage('SHOW_POP_FRAME_LOCK');
}
function callAppPage(appParam) {
	if(appParam) {
		appParam = JSON.parse(appParam);
		if(appParam && appParam.type) {
			switch(appParam.type) {
		  //   	case 'video': // 视频详情
				// 	var vid = appParam.vid;
				// 	var pid = appParam.pid;
				// 	if(vid && pid) {
				// 		openDetail(vid, pid);
				// 	} 
				// 	break;

				// case 'vlogger': // 红人主页
				// 	var cid = appParam.cid;
				// 	var pid = appParam.pid;
				// 	if(cid && pid) {
				// 		openUsersDetail(pid, cid);
				// 	} 
				// 	break;
				case 'shop':
					api.openWin({
				        name: 'shop',
				        url: "widget://html/product/shop.html",
				        pageParam: {
				        	_id: appParam.id
				        },
				        animation: {
				            type: "movein",
				            subType: "from_right"
				        },
				        reload: true
				    });							
					break;					
				case 'groupBuy':
					api.openWin({
				        name: 'groupbuying-detail-platform',
				        url: "widget://html/product/groupbuying-detail-platform.html",
				        pageParam: {
				        	_id: appParam.id,
				        	_gid: appParam.gid
				        },
				        animation: {
				            type: "movein",
				            subType: "from_right"
				        },
				        reload: true
				    });
					break;
				case 'product': // 商品详情
					var isOurmall = appParam.isOurmall;
					var pid = appParam.pid;
					var productId = appParam.productId;
					var sponsorShopId = appParam.sponsorShopId;
					if(isOurmall && ((pid) || (productId && sponsorShopId))) {
						openProDetail(isOurmall, pid, productId, sponsorShopId);
					}
					if(appParam.channelId && (!$api.getStorage('channelId')) && (!getCId())) {
						//唤醒参数有channelId，本地没有记录过channelId且没有登录过
						callAppPage(JSON.stringify({"type":"channelUser","channelId":appParam.channelId}));
					}
					break;

				case 'mall'://mall菜单
					if($api.getStorage('SHOW_POP_FRAME_LOCK') == 'true') return;
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuMall"), 1, true)'
					});
					break;

				case 'account'://account菜单
					if($api.getStorage('SHOW_POP_FRAME_LOCK') == 'true') return;
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuAccount"), 3, true)'
					});
					break;

				case 'show'://show列表菜单
					if($api.getStorage('SHOW_POP_FRAME_LOCK') == 'true') return;
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuShow"), 4, true)'
					});
					break;

				case 'cart'://cart列表菜单
					if($api.getStorage('SHOW_POP_FRAME_LOCK') == 'true') return;
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuCart"), 2, true)'
					});
					break;

				case 'showDetail'://show详情页
					var id = appParam.id;
					if(id) {
						openShowDetail(id, undefined, appParam.isVideo);
					} 
					break;
				case 'productGiveAway'://give away详情页
					var id = appParam.id;
					var pid = appParam.pid;
					var sid = appParam.sid;
					if(id && pid && sid) {
						openGiveDetail(id,pid,sid);
					}
					break;
				case 'activityList'://活动列表页
					openActivityList();
					break;
				
				case 'activityDetail':
					var id = appParam.id;
					var friendId = appParam.friendId ? appParam.friendId : null;
					if(id) {
						openActivityDetail(id, friendId);
					} 
					break;

				case 'openUrl'://webview打开链接
					gotoOurMallWeb(appParam.url, 'OurMall');
					break;
				
				case 'channelUser':
					//记录渠道用户标记，用于关联新用户与渠道id之间的关系
					$api.setStorage('channelId',appParam.channelId);
					setTimeout(function(){ openFansCoupon(); }, 1000);
					break;

				case 'newCoupon':
					UILoading = api.require('UILoading');
					UILoading.flower({
				        center: {
				            x: api.winWidth / 2.0,
				            y: api.winHeight / 2.0
				        },
				        size: 40,
				        fixed: true
				    }, function(ret) {
						startCouponPop(getCId());
				        setTimeout(function(){ UILoading.closeFlower(ret); }, 1000);
				    });
					break;
	    	}
	    }
	}
}

//打开付款遮罩
function payMask(type,msg){
	if(!type){
		$("body").append('<div class="pay-wait-mask">\
			<div class="pay-wait-inner">\
				<p>Payment in processing…</p>\
				<div style="position: relative;">\
					<div class="loader"></div>\
					<div class="sa-icon sa-success animate" style="display: none;">\
				      <span class="sa-line sa-tip "></span>\
				      <span class="sa-line sa-long "></span>\
				    </div>\
				    <div class="sa-icon sa-error animateErrorIcon" style="display: none;">\
				      <span class="sa-x-mark animateXMark">\
				        <span class="sa-line sa-left"></span>\
				        <span class="sa-line sa-right"></span>\
				      </span>\
				    </div>\
				</div>\
			</div>\
		</div>')
		$(".pay-wait-mask").show();
		return;
	}
	switch(type){
		case 'success':
			$(".pay-wait-mask").addClass('active');
			$(".pay-wait-inner p").text("Pay succeed");
			$(".sa-line").css("opacity",0);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-bottom-color","transparent");
			},500);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-left-color","transparent");
			},600);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-top-color","transparent");
				$(".sa-success").show();
				$(".sa-tip").addClass("animateSuccessTip").css("opacity",1);
			},700);
			setTimeout(function(){
				$(".sa-long").addClass("animateSuccessLong").css("opacity",1);
			},1450);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css({
					'border-bottom-color':"#A5DC86",
					'border-left-color':"#A5DC86",
					'border-top-color':"#A5DC86",
					'border-right-color':"#A5DC86",
					'opacity':".3"
				});
			},2300)
		break;
		case 'failed':
			$(".pay-wait-mask").addClass('active');
			$(".pay-wait-inner p").text(msg ? msg : "Payment canceled").css("color",'#E62117');
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-bottom-color","transparent");
			},500);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-left-color","transparent");
			},600);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("opacity",0);	
			},700);
			setTimeout(function(){
				$(".sa-error").show();
				$(".sa-x-mark").addClass("animateXMark");
			},1200);
			
		break;
	}
}
function getLocalTimeFromDatetime(datetime, type) {
	var timestamp = (new Date(datetime.replace(/-/g, '\/'))).getTime()/1000;
	switch(type) {
		case 'en':
			return formatEnTime(timestamp);
			break;
		default:
			return getLocalTime(timestamp);
			break;
	}
	return '';

}
function getLocalTime(nS) {       
    return  new Date(parseInt(nS) * 1000).Format("MM-dd-yyyy hh:mm");    
} 
function formatEnTime(nS){
	var time = new Date(parseInt(nS) * 1000).Format("MM-dd-yyyy").split('-'); 
	var MM = time.shift();
	switch (MM)
	{
		case '01':
			MM = 'Jan'
		break;
		case '02':
			MM = 'Feb'
		break;
		case '03':
			MM = 'Mar'
		break;
		case '04':
			MM = 'Apr'
		break;
		case '05':
			MM = 'May'
		break;
		case '06':
			MM = 'Jun'
		break;
		case '07':
			MM = 'Jul'
		break;
		case '08':
			MM = 'Aug'
		break;
		case '09':
			MM = 'Sep'
		break;
		case '10':
			MM = 'Oct'
		break;
		case '11':
			MM = 'Nov'
		break;
		case '12':
			MM = 'Dec'
		break;
	}
	return time[0]+' ' + MM +' '+time[1]
}
Date.prototype.Format = function (fmt) { //author: meizz   
        var o = {  
            "M+": this.getMonth() + 1, //月份   
            "d+": this.getDate(), //日   
            "h+": this.getHours(), //小时   
            "m+": this.getMinutes(), //分   
            "s+": this.getSeconds(), //秒   
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
            "S": this.getMilliseconds() //毫秒   
        }; 
        
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));  
        for (var k in o)  
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));  
        return fmt;  
    }
//是否空对象
function isEmptyObject(e) {  
    var t;  
    for (t in e)  
        return !1;  
    return !0  
} 
//日志
function appLog(Type,Json){
	var CustomerId = '-';
	if(Type != 9){
		getUserInfo('');
		var userInfo = JSON.parse(localStorage.getItem("OURMALL_USERINFO"));
		if(isEmptyObject(userInfo)) return;
		CustomerId = userInfo.customerId;
	}
	$.mamall_request('a:log.Log.insert',{
			type:Type,
			otherId:CustomerId,
			operationJson:JSON.stringify(Json)
	}, function(r) {
	},undefined,api);
}
//数组去重
function unique(array){ 
	var r = []; 
	for(var i = 0, l = array.length; i < l; i++) { 
		for(var j = i + 1; j < l; j++) 
			if (array[i] === array[j]) j = ++i; 
		r.push(array[i]); 
	} 
	return r; 
}
function saveLocalPageData(key, data, page, totalPage) {
	var saveData = {};
	var timestamp = Date.parse(new Date());
	timestamp = timestamp / 1000;
	saveData.html = data;
	saveData.timestamp = timestamp;
	saveData.page = page;
	saveData.totalPage = totalPage;
	key = 'PAGE_CACHE_DATA_' + key;
	$api.setStorage(key, saveData);
	return true;
}
function getLocalPageData(key) {
	key = 'PAGE_CACHE_DATA_' + key;
	return $api.getStorage(key);
}
function removeLocalPageData(key) {
	key = 'PAGE_CACHE_DATA_' + key;
	$api.rmStorage(key);
	return true;
}

filterBadgeActive = function(){
	switch($api.getStorage('activeMainMenu')){
		case 'mall':
			var cid = $api.getStorage('activeMallCategroy');
			var filterData = JSON.parse($api.getStorage('MallProductCategoryFilter'));
			if( !cid || cid == '9998' || cid == '9999' || cid == '9997') return;
			if(typeof filterData[cid].specificsQueryCond == 'object'){
				filterData[cid].specificsQueryCond = filterData[cid].specificsQueryCond.join(',');
				filterData[cid].specificsQueryCond = filterData[cid].specificsQueryCond.replace(/All/g,'');
				filterData[cid].specificsQueryCond = filterData[cid].specificsQueryCond.replace(/,/g,'');
			}
			if( filterData[cid].nameLike || filterData[cid].minPrice || filterData[cid].maxPrice || filterData[cid].sortBy || filterData[cid].specificsQueryCond){
				$(".header-container .right-btns .icon0-filter .badge").addClass('active');
			}else{
				$(".header-container .right-btns .icon0-filter .badge").removeClass('active');
			}
			break;
		case 'show':
			var cid = $api.getStorage('activeShowCategroy');
			var filterData = JSON.parse($api.getStorage('ShowProductCategoryFilter'));
			if( !cid || cid == '9998' || cid == '9999') return;
			if(filterData[cid].nameLike || filterData[cid].sortBy){
				$(".header-container .right-btns .icon0-filter .badge").addClass('active');
			}else{
				$(".header-container .right-btns .icon0-filter .badge").removeClass('active');
			}
			break;
		default:
			break;
		
	}
	
}
function in_array(val, arr) {
	for(var i = 0; i < arr.length; i ++) {
		if(arr[i] == val) {
			return true;
		}
	}
	return false;
}
function shakeRotate(){
	$('.pop-switch.shake-rotate').addClass('active');
	setTimeout(function(){
			$('.pop-switch.shake-rotate').removeClass('active');
		},1000);
}
function imgWH(el){
	var Img = new Image(),
		_src = $(el).prop('src');
	Img.src = _src;
	Img.onload = function(){
		var imgW = el.width,
			imgH = el.height;
		if(imgW>=imgH){
			$(el).height(70).width('auto');
		}else{
			$(el).width(70).height('auto');
		}	
	}
}
function autocompleActive(_switch){
	if(_switch){
		$('.search-comple').show();
		$('#wrap').hide();
	}else{
		$('.search-comple').hide();
		$('#wrap').show();
	}
	
}

function rightTopBtnStatus(){
	var menuActive = $api.getStorage('activeMainMenu'),
		mallMenuActive =  $api.getStorage('activeMallCategroy'),
		showMenuActive =  $api.getStorage('activeShowCategroy');
	
	$('#header .right-btns span').hide(); //reset
	if( menuActive == 'mall'){
		if(mallMenuActive == '9998'){
			$('#header .right-btns span.icon0-search').show();
		}
		if(mallMenuActive && mallMenuActive != '9998' && mallMenuActive != '9999'){
			$('#header .right-btns span.icon0-filter').show();
		}else if(mallMenuActive == '9999'){
			$('#header .right-btns span[title=mallDel]').show();
		}
	}else if( menuActive == 'show' ){
		if(showMenuActive && showMenuActive != '9998' && showMenuActive != '9999'){
			$('#header .right-btns span.icon0-filter').show();
		}else if(showMenuActive == '9999'){
			$('#header .right-btns span[title=showDel]').show();
		}	
	}

}

function delRecentlyView(type){
	var clearCacheFunction = menuKey = '';
	switch(type) {
		case 'mall':
			if(! localStorage.getItem("RV-Key")) return;
			menuKey = 'AppMenuMall';
			clearCacheFunction = 'localStorage.removeItem("RV-Key");';
			break;

		case 'show':
			if((! getCId()) && (! $api.getStorage("showViewedHistory"))) return;
			menuKey = 'AppMenuShow';
			clearCacheFunction
			if(getCId()) {
				//登录状态
				clearCacheFunction = "$.mamall_request('a:show.Show.clearOurmallView',{customerId:getCId()},function(r){ $api.rmStorage('showViewedHistory'); },undefined,api);";
				
			} else {
				clearCacheFunction = '$api.rmStorage("showViewedHistory");';
			}
			break;
	}

	api.confirm({
	    msg: $.i18n.prop("Confirm to clear the view history?"),
	    buttons: [$.i18n.prop("OK"), $.i18n.prop("Cancel")]
	}, function(ret, err) {
	    var index = ret.buttonIndex;
	    if(index==1){
	    	eval(clearCacheFunction);
	    	api.execScript({
	    		name:'main',
				script: 'goTopAndRefresh("' + menuKey + '", true);'
	    	});
	    }
	});
}

function openShareMask(_targets,_data){
	UILoading = api.require('UILoading');
	UILoading.flower({
        center: {
            x: api.winWidth / 2.0,
            y: api.winHeight / 2.0
        },
        size: 40,
        fixed: true
    }, function(ret) {
        setTimeout(function(){ UILoading.closeFlower(ret); }, 500);
    });
	api.openFrame({
		name: 'share-mask',
		url: 'widget://html/main/share-mask.html',
		pageParam: {
			_targets: _targets,
			_data: _data
		},
		bounces: false,
		bgColor: 'rgba(0,0,0,.7)',
		vScrollBarEnabled: false,
		hScrollBarEnabled: false
	});
	$api.setStorage("openShareState",true);
	api.addEventListener({
		name : 'keyback'
	}, function (ret, err) {  
		if($api.getStorage("openShareState")){
			api.execScript({
	    		frameName: 'share-mask',
				script: 'closeMask()'
	    	});
		}
	});
}

//打开客服聊天
function openChatMessage(){	
	var _data = new Object;
	switch(api.winName){
		case 'pro-detail-platform'://ourmall商品页面
			_data.pic =  listJson.imgUrl1;
			_data.title = listJson.name;
			_data.price = listJson.defaultPrice;
			_data.pid = api.pageParam._pid;
			_data.sid = api.pageParam._sid;
			break;
		case 'showDetail': case 'show-detail-vid'://show详情
			_data.pic =  preViewArr[0];
			_data.title = lastViewShowData.show.title;
			_data.showId = api.pageParam.id;
			break;
		case 'order-detail': //订单详情
			_data.pic = detailData.OrderDetail.orderPlus[0].img;
			_data.title = detailData.OrderDetail.code;
			_data.price = detailData.OrderDetail.itemTotal;
			_data.code = orderCode;
			break;
		case 'main':
			//沉浸式状态栏
			if(api.systemType=="ios"){
	            if(parseInt(api.systemVersion,10)>=7){
		               api.addEventListener({
						    name:'viewappear'
						}, function(ret, err){
							setTimeout(function(){
								api.setStatusBarStyle({
								    style: 'light',
								    color:'transparent'
								});
							},200);
						});
		           }
		    	}
			break;
		//default:
			
	}
	//
	api.openWin({
	    name:'chat-message',
	    url: 'widget://html/main/chat-message.html',
	    animation:{
	    	type:"movein",
	    	subType:"from_right"
	    },
	    bgColor:'rgba(255,255,255,0)',
	    reload: true,
	    slidBackEnabled: false,
	    pageParam:{
	    	winName: api.winName,
	    	frameName: api.frameName,
	    	parentPageData: _data
	    }
	});
}

function HTMLEncode(html) {
    var temp = document.createElement("div");
    (temp.textContent != null) ? (temp.textContent = html) : (temp.innerText = html);
    var output = temp.innerHTML;
    temp = null;
    return output;
}
function startCheckPushStatus(type){
	var lastTimeCheckPush = localStorage.getItem("LAST_TIME_CHECK_PUSH");
	var d = new Date();
	var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
	if(lastTimeCheckPush && lastTimeCheckPush != today) {
		var ajpush = api.require('ajpush');
		if(api.systemType != 'ios') {
			//android
			ajpush.init(function(ret) {
				if(ret.status == 1){
					ajpush.isPushStopped(function(cRet) {
					    if(cRet && cRet.isStopped == true){
							checkPushStatusAlert(type);
					    }
					});
				}
			});
		} else {
			//ios
			ajpush.isPushStopped(function(cRet) {
			    if(cRet && cRet.isStopped == true){
					checkPushStatusAlert(type);
			    }
			});
		}
	}
	if(lastTimeCheckPush == null) {
		localStorage.setItem("LAST_TIME_CHECK_PUSH", today);
	}
	
}
function checkPushStatusAlert(type) {
	//检查各种状态下是否打开了推送开关
	var keyPlusString = type + '_VER_' + api.appVersion;
	var pushStatusKey = 'PUSH_STATUS_' + keyPlusString;
	var todayNotifyKey = 'PUSH_STATUS_TODAY_NOTIFY_' + keyPlusString;
	var alertStatus = $api.getStorage(pushStatusKey);
	var todayNotify = $api.getStorage(todayNotifyKey);
	todayNotify = todayNotify ? parseInt(todayNotify) : 0;
	var message = '';
	var title = $.i18n.prop("Enable OurMall push notifications");
	var timestamp = Date.parse(new Date());
	timestamp = timestamp / 1000;

	if((alertStatus != 'true') && (todayNotify + 86400 < timestamp)) {
		$api.setStorage(todayNotifyKey, timestamp);
		switch(type) {
			case 'order':
				message = $.i18n.prop("Push you the lastest order's status immediately!");
				break;
			case 'common':
			default:
				message = $.i18n.prop("Special coupons, fashion shows, you wouldn't miss it!");
				break
		}
		api.confirm({
			title: title,
		    msg: message,
		    buttons: [$.i18n.prop("No, thanks."), $.i18n.prop("Sure, let me try!")]
		}, function(ret, err) {
		    if(ret && ret.buttonIndex == 2) {
		    	api.openApp({
				    iosUrl: 'app-settings:',
				    androidPkg: 'com.android.settings'
				}, function(ret, err) {
				    
				});
		    } else {
		    	//确定不打开，当前版本不再提醒
		    	$api.setStorage(pushStatusKey, 'true');
		    }
		});
	}
}

function scrollToBottom(){
	if(localStorage.getItem('scrollToBottomFlag') == 'false') return false;
	$('html,body').animate({scrollTop: $(document).height() + $(window).height() + 1000}, 500);
	localStorage.setItem('scrollToBottomFlag','false');
	setTimeout(function(){
		localStorage.setItem('scrollToBottomFlag','true');
	},500);
}
var checkCustomerServiceTimer;

//获取未读取客服系统消息
function getCustomerService(){
	clearTimeout(checkCustomerServiceTimer);
	api.addEventListener({
	    name: 'CustomerServiceStatus'
	}, function(ret, err) {
		if(ret.value.status == true){
			$('#toChatMessage').addClass('active');
			localStorage.setItem('CustomerServiceUnreadStatus', 'true');
		}else{
			localStorage.removeItem('CustomerServiceUnreadStatus');
			$('#toChatMessage').removeClass('active');
		} 
	});
	if(!$api.getStorage('chatVisit') &&  typeof $api.getStorage('OURMALL_CHATLIST') != 'object' ){
        //重来没有访问过chat加红点
	    api.sendEvent({
		    name: 'CustomerServiceStatus',
		    extra: { status: true }
		});
	}
	if(getCId()) {
		$.mamall_request('video.account.menunumber',{
	        OM_DEVICE_UUID:api.deviceId,
	        customerId:getCId()
	   }, function(r) {
	        if('9999' == r.ErrorCode) {
	        	if(r.Data.CustomerService && r.Data.CustomerService.cnt > 0) {
	        		//检查是否有未读客服留言
				    api.sendEvent({
					    name: 'CustomerServiceStatus',
					    extra: { status: true }
					});
	        	}
	        }
	    }, undefined, api);
	}
	//加定时器，10分钟检查一次
	checkCustomerServiceTimer = setTimeout(function() {
		getCustomerService();
	}, 600000);
}

//插入客服图标
$(function(){
	var _html = '<li class="ourmallfont icon0-cs" tapmode onclick="openChatMessage()" id="toChatMessage"></li>';
	if($('#scroll-top').length>0){
		$('.button-menu>#scroll-top').before(_html);
	}else{
		$('.button-menu').append(_html);
	}
	if(localStorage.getItem('CustomerServiceUnreadStatus') == 'true') {
		$('#toChatMessage').addClass('active');
	}
	sideCouponsStatus();
});

//分享赚的弹层
openshareEarnmask = function(){
	$api.setStorage('openShareEarnState',1);
	api.openFrame({
		name:'pro-share-mask',
        url: 'widget://html/product/pro-share-mask.html',
		pageParam: {
		},
		bounces: false,
		bgColor: 'rgba(0,0,0,.7)',
		vScrollBarEnabled: false,
		hScrollBarEnabled: false
	});
}

//商品size-guide
openSizeGuide =	function (){
	api.openWin({
	    name: 'pro-size-guide',
	    url: 'widget://html/product/pro-size-guide.html',
	    bounces: false,
	    bgColor:'#fff',
	    reload:'true',
	    progress:{
	    	type:'page',
	    	color:'#E62117'
	    }
	});
}
//尝试打开应用
openOfficialSns = function(type) {
	var name = url = iosAppName = androidAppName = '';
	var callParams = {}
	switch(type) {
		case 'facebook':
			name = 'OurMall-Facebook';
			url = 'https://www.facebook.com/837301976403193';
			callParams['iosUrl'] = 'fb://page?id=837301976403193';
			if(api.systemType == 'android') {
				callParams['androidAppName'] = 'com.facebook.katana';
				callParams['uri'] = 'fb://page/837301976403193';
			}
			break;
		case 'twitter':
			name = 'OurMall-Twitter';
			url = 'https://twitter.com/ourmall_app';
			callParams['iosUrl'] = 'twitter://user?id=723084597555159044';
			if(api.systemType == 'android') {
				callParams['androidAppName'] = 'com.twitter.android';
				callParams['uri'] = 'twitter://user?id=723084597555159044';
			}
			break;
		case 'instagram':
			name = 'OurMall-Instagram';
			url = 'https://www.instagram.com/ourmall_app/';
			callParams['iosUrl'] = 'instagram://user?username=ourmall_app';
			if(api.systemType == 'android') {
				callParams['androidAppName'] = 'android.intent.action.VIEW';
				callParams['uri'] = 'instagram://user?username=ourmall_app';
			}
			break;
	}
	api.openApp(callParams, function(ret, err) {
	    if (ret) {
	    } else {
	        api.openWin({
		        name: name,
		        url: "widget://html/product/webpage.html",
		        pageParam: {_url:url,name:name.replace('-', ' ')},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true,
		        slidBackEnabled: false
		    });
	    }
	});
}

//沉浸式
function fixStatusBar(el){
    if(api.systemType=="ios"){
        if(parseInt(api.systemVersion,10)>=7){
               el.style.paddingTop = '20px';
               el.style.backgroundColor = '#ffffff';
        }else{
               el.style.paddingTop = '0px';
        }
        api.setStatusBarStyle({
		    style: 'dark',
		    color:'#ffffff'
		});
    }else{
    	var statusBar = api.require('statusBar');
		//同步返回结果：
		var statusBarHeight  = statusBar.getStatusBarHeight();
        if(parseFloat(api.systemVersion)>=4.4 && parseFloat(api.systemVersion)<=5.0){
            el.style.paddingTop = statusBarHeight+'px';
            el.style.backgroundColor = '#000000';
        }else if(parseFloat(api.systemVersion)>5.0){
    		el.style.paddingTop = statusBarHeight+'px';
            el.style.backgroundColor = '#000000';
        }else{
            el.style.paddingTop = '0px';
        }
    }
}
function setFullscreen(){
	setInterval(function(){ 
		api.setFullScreen({
			fullScreen: false
		});
	}, 100);
}

function sideOpenMyCoupons(el){
	api.openWin({
        name:'coupon-list',
        url: 'widget://html/account/my-coupon-list.html',
        animation:{
            type:"movein",
            subType:"from_right"
        },
        reload:true
    });
	return; //又不要了
	if($(el).hasClass('full')){
		$(el).removeClass('full');
	}else{
		$(el).addClass('full').removeClass('active');
	}
}

//获取15分钟优惠券
var setTimeStam;
var thMinuteCouponsFlag = true;
function thMinuteCoupons(){
	if(getCId()){
		if(!thMinuteCouponsFlag) return;
		thMinuteCouponsFlag = false;
		$.mamall_request('coupon.findbycustomer',{customerId:getCId(),H5_API_REQUEST_CACHE_SET:2}, function(r) {
			if (r.ErrorCode == '9999'){
				clearInterval(setTimeStam);
				var couponsData = r.Data.coupon;
				if(couponsData.length > 0 ){
					var timeStampArr = [];
					for( var i = 0; i < couponsData.length; i++){
						timeStampArr.push(couponsData[i].leftTimestamp);
					}
					var minTimeStamp = Math.min.apply(Math, timeStampArr);
					$api.setStorage('minThMinuteCouponTimeStamp',minTimeStamp);
					setTimeStam = setInterval(function(){
						$api.setStorage('minThMinuteCouponTimeStamp',minTimeStamp--);
					},1000)	
				}else{
					$api.rmStorage('minThMinuteCouponTimeStamp');
				}
				api.sendEvent({
					name: 'thMinutCouponsStatus'
				});
			}
			thMinuteCouponsFlag = true;
		},undefined,api);
	}
}
var sideCouponsTime = 0;
var shakeTime = 0;
function sideCouponsStatus(){
	clearInterval(sideCouponsTime);
	clearInterval(shakeTime);
	var minThMinuteCouponTimeStamp = $api.getStorage('minThMinuteCouponTimeStamp');
	formatSeconds(minThMinuteCouponTimeStamp);
	if($('.button-menu .icon0-coupon-side').length>0){
		$('.button-menu .icon0-coupon-side').remove();
	}
	if(minThMinuteCouponTimeStamp>0 || $api.getStorage('couponAlertTimeStatus')){
		var _html = '<li class="ourmallfont icon0-coupon-side shake-rotate" tapmode onclick="sideOpenMyCoupons()" id="sideCoupon"><i class="ourmallfont icon0-coupon-side"></i><span>Expired<span></span></span></li>'
		$('.button-menu').prepend(_html);
		
		if($('.icon0-coupon-side').length>0){
			shakeTime = setInterval(function(){
				$('.icon0-coupon-side:not(.full)').addClass('active');
				setTimeout(function(){
					$('.icon0-coupon-side').removeClass('active');
				},800)
			},5000)
		}
	}
	sideCouponsTime = setInterval(function(){
		var _val = $('.button-menu .icon0-coupon-side').attr('data-seconds');
		$('.button-menu .icon0-coupon-side>span>span').text(formatSeconds(_val));
		_val--;
		$('.button-menu .icon0-coupon-side').attr('data-seconds',_val);
		if(_val <= 0 ){
			clearInterval(sideCouponsTime);
			clearInterval(shakeTime);
			sideCouponsStatus();
		}
	},1000)
	
}
function formatSeconds(value) { 
	var second = parseInt(value);
	var minute = 0;

	if( second > 60){
		minute = parseInt(second/60); 
		second = parseInt(second%60); 
		result = (minute < 10 ? '0' + minute : minute) + ':' + (second<10 ? '0' + second : second)
	}else{
		result = '00:' + (second<10 ? '0' + second : second)
	}
	return result; 
}
function formatSecondsHMS(value,type){
	var second = parseInt(value),
		minute = 0,
		hour = 0;
	hour = Math.floor(second/3600);
	minute = Math.floor(Math.floor(second%3600)/60);
	second = Math.floor(second%60);
	if(hour < 10)  hour = '0' + hour.toString();
	if(minute < 10)  minute = '0' + minute.toString();
	if(second < 10)  second = '0' + second.toString();	
	switch(type){
		case 'h':
			return hour
			break;
		case 'm':
			return minute
			break;
		case 's':
			return second
			break;
		default:
		return hour + ' : ' + minute + ' : ' + second;
	}
	
}

function loadProperties() {
	//测试app根目录 A6935447364713/
	//正式android app根目录 com.ourmall/widget/
	//正式iOS app根目录 
	var nowLanguage = localStorage.getItem('DEFAULT_APP_LANGUAGE') ? localStorage.getItem('DEFAULT_APP_LANGUAGE') : 'en';
	var resourcePath = document.location.pathname;
	var findString = '';
	if(resourcePath.indexOf('A6935447364713') >= 0) {
		findString = 'A6935447364713/';
	} else {
		findString = 'widget/';
	}
	var startPos = resourcePath.indexOf(findString);
	resourcePath = resourcePath.substring(startPos);
	var arrPath = resourcePath.replace(findString, '').split('/');
	var relativePath = '';
	for(var i = 0; i < arrPath.length; i ++) {
		if(i > 0) {
			relativePath += '../';
		}
	}
	relativePath = relativePath + 'i18n/';
	try {
		jQuery.i18n.properties({
	        name : 'strings',
	        path : relativePath,
	        mode : 'map',
	        language : nowLanguage,
	        callback : function() {
	            $('[i18n-tag]').each(function() {
	                $(this).removeAttr('i18n-tag').text($.i18n.prop($(this).text()));
	            });
	        }
	    });
	} catch(e) {

	}
}
$(function(){
	//加载多语言文字包
	loadProperties();
});

function openFansCoupon(){
	var channelCouponStatus = $api.getStorage('GET_CHANNEL_FIRST_COUPON_STATUS') == 'true' ? true : false;
	if($api.getStorage('NEED_REOPEN_GET_CHANNEL_COUPON_MASK') == 'true') return; // 防止登录后出现2次领取优惠券弹层
	if(! channelCouponStatus) {
		if($api.getStorage('channelId')) {
			$.mamall_request('a:web.Channel.get',{
				id: $api.getStorage('channelId')
			}, function(r) {
				if(r.ErrorCode == '9999' && r.Data.firstDiscount > 0 && r.Data.firstDiscount < 1) {
					getUserInfo('');
					var popOption = new Object;
					popOption.customerId = getCId();
					popOption.couponType = 4;//渠道新用户送优惠券
					$.mamall_request('coupon.hasget', popOption, function(r) {
				    	if (r.ErrorCode == '9999'){
				    		if(! r.Data.hasCoupon){
								$api.setStorage('SHOW_POP_FRAME_LOCK', 'true');
				    			api.openFrame({
									name: 'pop-fans-coupon-mask',
									url: 'widget://html/pop/pop-fans-coupon-mask.html',
									bounces: false,
									bgColor: 'rgba(0,0,0,.7)',
									pageParam: {
										
									},
									vScrollBarEnabled: false,
									hScrollBarEnabled: false,
									reload: true
								});
				    		} else {
				    			$api.setStorage('GET_CHANNEL_FIRST_COUPON_STATUS', 'true');
				    			api.alert({
									msg: $.i18n.prop("You have aleady got the coupons, enjoy shopping!"),
								}, function(ret, err) {
									api.closeFrame({
										name: 'pop-fans-coupon-mask'
									});
								});
				    		}
				    	}
				    }, undefined, api);
				} else {
					$api.setStorage('GET_CHANNEL_FIRST_COUPON_STATUS', 'true');
				}
			},undefined,api);
		}
	} 
}
//提示优惠券即将过期
function alertCouponExpire(_time){
	api.openFrame({
		name: 'pop-coupon-countdown-mask',
		url: 'widget://html/pop/pop-coupon-countdown-mask.html',
		bounces: false,
		bgColor: 'rgba(0,0,0,.7)',
		pageParam: {
			time:_time
		},
		vScrollBarEnabled: false,
		hScrollBarEnabled: false,
		reload: true
	});
}
