//Account页面相关js方法

//my-favorites
function openMyfavorite() {
	api.openWin({
		name: "myfavorite",
		url: "widget://html/account/my-favorites.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//contact-ourmall
function openContact() {
	api.openWin({
		name: "contactourmall",
		url: "widget://html/account/contact-ourmall.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//about-ourmall
function openAbout() {
	api.openWin({
		name: "aboutourmall",
		url: "widget://html/account/about-ourmall.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//privacy
function openPrivacy() {
	api.openWin({
		name: "privacy",
		url: "widget://html/account/privacy.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//feedback
function openFeedback() {
	api.openWin({
		name: "feedback",
		url: "widget://html/account/feedback.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//message
function openMessage() {
	api.openWin({
		name: "message",
		url: "widget://html/account/message.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//setting
function openSetting() {
	api.openWin({
		name: "AccountSetting",
		url: "widget://html/account/setting.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		reload: true
	});
}
//打开订单列表
function openMyOrder(status) {
	if(!status) status = 0;
	api.openWin({
		name:'my-orders',
		url : 'widget://html/account/my-orders.html',
		animation: {
			type: "movein",
			subType: "from_right"
		},
		pageParam:{
			status:status
		}
	});
};
//打开地址列表
function openAddressList() {
    api.openWin({
        name:'address-list',
        url: 'widget://html/account/address-list.html',
        pageParam: { fromAccount:1 },
        animation:{
            type:"movein",
            subType:"from_right"
        },
        reload:true
    });
}
//获取订单数量
function getMenuNumber(){
	var loadingId = '';
    var UILoading = api.require('UILoading');
    UILoading.flower({
        center: {
            x: api.winWidth / 2.0,
            y: api.winHeight / 2.0
        },
        size: 40,
        fixed: true
    }, function(ret) {
        loadingId = ret;
    });

    $.mamall_request('video.account.menunumber',{
        OM_DEVICE_UUID:api.deviceId,
        customerId:getCId()
    }, function(r) {
        if('9999' == r.ErrorCode) {
            if(loadingId) {
                UILoading.closeFlower(loadingId);
            }
            //订单、未读消息、Feedback、任务数量
            for(var name in r.Data) {
                var thisObj = r.Data[name];
                if(name == 'Order') {
                    for(var i in thisObj){
                        if(thisObj[i] > 0) {
                            $('#spanCnt' + i).html(thisObj[i]).show();
                        }
                    }
                } else {
                    if(thisObj.cnt) {
                        $('#spanCnt' + name).html(thisObj.cnt).show();
                    }
                }
            }
        }
    }, undefined, api);
}
//打开我的show列表
function openMyShowList() {
	api.openWin({
        name: 'myshow-list',
        url: "widget://html/show/myshow-list.html",
        animation: {
            type: "movein",
            subType: "from_right"
        },
        reload: true
    });
}