function AROpenFun() {
	openDetail = function(vid, pid) {
		api.openWin({
	        name: 'detail',
	        url: "widget://html/product/detail.html",
	        pageParam: {vid:vid,pid:pid},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	openUsersDetail = function(pid, cid) {
		api.openWin({
	        name: 'user-detail',
	        url: "widget://html/product/user-detail.html",
	        pageParam: {cid:cid,pid:pid},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	var proIdArr;
	openProDetail = function(type,_pid,_tpid,_sid) {	
		if(!!_tpid && !!_sid){
			var proId = {};
			proId[_tpid+'_'+_sid] = 1;
			if(!localStorage.getItem('RV-Key')){
				localStorage.setItem('RV-Key','[]');
			}
			var proIdArr = JSON.parse(localStorage.getItem('RV-Key'));
			if(!Object.prototype.toString.call(proIdArr) === '[object Array]'){
				proIdArr = new Array;
			}
			for( var i=0; proIdArr.length>i;i++ ){
				
				if(typeof proIdArr[i] != 'object'){//老数据升级新数据
					var _oldpid = proIdArr[i];
					proIdArr[i] = {};
					proIdArr[i][_oldpid] = 1;
				}
				for(var obj in proIdArr[i]){
					if(obj == _tpid+'_'+_sid){
						oldProId = proIdArr[i];
						proId[_tpid+'_'+_sid] = proIdArr[i][_tpid+'_'+_sid] +1;
						proIdArr.splice(i, 1);
						break;
					}
				}
			}
			proIdArr.push(proId);
			//proIdArr = getArray(proIdArr);
			if(proIdArr.length>=50){
				proIdArr.shift();
			}
			//存本地
			localStorage.setItem('RV-Key',JSON.stringify(proIdArr));
			//存接口
			var localUinfo = JSON.parse(localStorage.getItem('OURMALL_USERINFO'));
			var customerId;
			if(!isEmptyObject(localUinfo)) customerId = localUinfo.customerId;
			if(customerId){
				var crvApiOption = new Object;
				crvApiOption.customerId = customerId;
				crvApiOption.plus = _tpid+'_'+_sid;
				crvApiOption.productIdJson = JSON.stringify(proIdArr);
				$.mamall_request('customer.recentlyViewed', crvApiOption, function(){},undefined,api);
			}		
		}
		if(type == '2'){
			api.openWin({
		        name: 'pro-detail',
		        url: "widget://html/product/pro-detail.html",
		        pageParam: {_pid:_pid},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true
		    });
		} else if (type == '3') { // show详情的非ourmall商品
			api.openWin({
		        name: 'pro-detail',
		        url: "widget://html/product/pro-detail.html",
		        pageParam: {_pid:_pid, source:'show'},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true
		    });
		}
		else{
			api.openWin({
		        name: 'pro-detail-platform',
		        url: "widget://html/product/pro-detail-platform.html",
		        pageParam: {_pid:_tpid,_sid:_sid},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true
		    });
		}
	}
	openReviewList = function(reviewInfo) {
		api.openWin({
	        name: 'FeedbackList',
	        url: "widget://html/product/pro-detail-review.html",
	        pageParam: {reviewInfo:reviewInfo},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	openVlgReviewList = function(reviewInfo) {
		api.openWin({
	        name: 'VloggerFeedbackList',
	        url: "widget://html/product/pro-detail-vlg-review.html",
	        pageParam: {reviewInfo:reviewInfo},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	openActivityList = function() {
		api.openWin({
	        name: 'activityList',
	        url: "widget://html/show/activity-list.html",
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	//进入活动列表
	openActivityDetail = function(id) {
		gotoOurMallWeb(hostURL() + '?m=activity&a=activityDetail&id=' + id, 'Topic Show');
	}
	//打开详情
	openShowDetail = function (id,type) {
		api.openWin({
	        name: 'showDetail',
	        url: "widget://html/show/show-detail.html",
	        pageParam: {id:id,type:type},
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
    };
}
function getArray(a) {
 var hash = {},
     len = a.length,
     result = [];

 for (var i = 0; i < len; i++){
     if (!hash[a[i]]){
         hash[a[i]] = true;
         result.push(a[i]);
     } 
 }
 return result;
}

