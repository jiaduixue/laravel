/*! Lazy Load 1.9.7 - MIT license - Copyright 2010-2015 Mika Tuupola */
!function(a,b,c,d){var e=a(b);a.fn.lazyload=function(f){function g(){var b=0;i.each(function(){var c=a(this);if(!j.skip_invisible||c.is(":visible"))if(a.abovethetop(this,j)||a.leftofbegin(this,j));else if(a.belowthefold(this,j)||a.rightoffold(this,j)){if(++b>j.failure_limit)return!1}else c.trigger("appear"),b=0})}var h,i=this,j={threshold:0,failure_limit:0,event:"scroll",effect:"show",container:b,data_attribute:"original",skip_invisible:!1,appear:null,load:null,placeholder:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"};return f&&(d!==f.failurelimit&&(f.failure_limit=f.failurelimit,delete f.failurelimit),d!==f.effectspeed&&(f.effect_speed=f.effectspeed,delete f.effectspeed),a.extend(j,f)),h=j.container===d||j.container===b?e:a(j.container),0===j.event.indexOf("scroll")&&h.bind(j.event,function(){return g()}),this.each(function(){var b=this,c=a(b);b.loaded=!1,(c.attr("src")===d||c.attr("src")===!1)&&c.is("img")&&c.attr("src",j.placeholder),c.one("appear",function(){if(!this.loaded){if(j.appear){var d=i.length;j.appear.call(b,d,j)}a("<img />").bind("load",function(){var d=c.attr("data-"+j.data_attribute);c.hide(),c.is("img")?c.attr("src",d):c.css("background-image","url('"+d+"')"),c[j.effect](j.effect_speed),b.loaded=!0;var e=a.grep(i,function(a){return!a.loaded});if(i=a(e),j.load){var f=i.length;j.load.call(b,f,j)}}).attr("src",c.attr("data-"+j.data_attribute))}}),0!==j.event.indexOf("scroll")&&c.bind(j.event,function(){b.loaded||c.trigger("appear")})}),e.bind("resize",function(){g()}),/(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion)&&e.bind("pageshow",function(b){b.originalEvent&&b.originalEvent.persisted&&i.each(function(){a(this).trigger("appear")})}),a(c).ready(function(){g()}),this},a.belowthefold=function(c,f){var g;return g=f.container===d||f.container===b?(b.innerHeight?b.innerHeight:e.height())+e.scrollTop():a(f.container).offset().top+a(f.container).height(),g<=a(c).offset().top-f.threshold},a.rightoffold=function(c,f){var g;return g=f.container===d||f.container===b?e.width()+e.scrollLeft():a(f.container).offset().left+a(f.container).width(),g<=a(c).offset().left-f.threshold},a.abovethetop=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollTop():a(f.container).offset().top,g>=a(c).offset().top+f.threshold+a(c).height()},a.leftofbegin=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollLeft():a(f.container).offset().left,g>=a(c).offset().left+f.threshold+a(c).width()},a.inviewport=function(b,c){return!(a.rightoffold(b,c)||a.leftofbegin(b,c)||a.belowthefold(b,c)||a.abovethetop(b,c))},a.extend(a.expr[":"],{"below-the-fold":function(b){return a.belowthefold(b,{threshold:0})},"above-the-top":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-screen":function(b){return a.rightoffold(b,{threshold:0})},"left-of-screen":function(b){return!a.rightoffold(b,{threshold:0})},"in-viewport":function(b){return a.inviewport(b,{threshold:0})},"above-the-fold":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-fold":function(b){return a.rightoffold(b,{threshold:0})},"left-of-fold":function(b){return!a.rightoffold(b,{threshold:0})}})}(jQuery,window,document);

//lazyload
function imgLoad(){
	var option = {
		threshold: 100,
		load:function(){
			var obj = $(this);
			obj.attr("data-lazyload",false);
			if(obj.parent().parent().hasClass('mui-grid-9')){
				var _img = new Image();
				_img.src = obj.attr("data-original");
				_img.onload = function(){
					var imgW = _img.width,
						imgH = _img.height;
					if(imgW>=imgH){
						obj.css("background-size","auto 100%");	
					}else{
						obj.css({"background-size":"100% auto"});	
					}	
				}
				
			}
			if(obj.parent().parent().parent('#divReviewImage').length>0){
				imgWH(this);
			}
			if(typeof(obj.attr('data-autowh'))!='undefined'){
				var _img = new Image();
				_img.src = obj.attr("data-original");
				_img.onload = function(){
					var imgW = _img.width,
						imgH = _img.height;
					if(imgW>=imgH){
						obj.css("background-size","auto 100%");	
					}else{
						obj.css({"background-size":"100% auto"});	
					}	
				}
			}
			
		}
	}
	jQuery("[data-lazyload=true]").lazyload(option);
}

function getCId(){
	var localUinfo = localStorage.getItem("OURMALL_USERINFO");
	localUinfo = localUinfo ? JSON.parse(localUinfo) : "";
	if(localUinfo && localUinfo.customerId){
		return localUinfo.customerId;
	}else{
		return "";
	}
}
function getUserInfo(callback) {
	if(localStorage.getItem("OURMALL_USERINFO")) {
		//如果有本地登录信息，直接返回
		userData = JSON.parse(localStorage.getItem("OURMALL_USERINFO"));
		$api.rmStorage('LAST_PAGE_BEFORE_LOGIN');
		if(typeof(callback) == 'string'){
			if(callback) {
				eval(callback);
			} else {
				return true;
			}
		} else {
			callback(userData);
		}
	} else {
		var UILoading = api.require('UILoading');
		var loadingId;
		if(callback) {
			UILoading.flower({
			    center: {
			        x: api.winWidth / 2.0,
					y: api.winHeight / 2.0
			    },
			    size: 40,
			    fixed: true
			}, function(ret) {
			    loadingId = ret;
			});
		}
		var type = 0;
		if(api.systemType == 'ios') {
			type = 2;
		} else {
			type = 1;
		}
		$.mamall_request('member.getmemberbyuids', {
			mPlatform: type,
			jpushCode: localStorage.getItem("OURMALL_RGID"),
			OM_DEVICE_UUID: api.deviceId,
			H5_API_REQUEST_CACHE_SET: 2
		}, function(r) {
			if(loadingId) {
				UILoading.closeFlower(loadingId);
			}
			if('9999' == r.ErrorCode) {
				var userData = r.Data.Customer;
				if(userData.customerId){
					$api.rmStorage('LAST_PAGE_BEFORE_LOGIN');
					localStorage.setItem("OURMALL_USERINFO",JSON.stringify(userData));
					if(typeof(callback) == 'string'){
						if(callback) {
							eval(callback);
						} else {
							return true;
						}
					} else {
						callback(userData);
					}
				}else{
					if(callback != '') {
						api.openWin({
							name: "login",
							url: "widget://html/account/login.html",
							animation: {
								type: "movein",
								subType: "from_right"
							},
							reload: true
						});
					} else {
						return false;
					}
				}
			}
		},"",api);
	}
	return false;
}

function goCart(){
	api.execScript({
	    name: 'main',
	    script: 'changeFrame(document.getElementById("AppMenuCart"), 2, true);'
	});
	api.openWin({
    	name: 'main',
    	slidBackEnabled:false,
    	animation:{
	    	type:'none'
	    }
	});
	setTimeout(function(){ api.closeWin({}) }, 200);
}
function scrollToTop(){
	$('html, body').animate({scrollTop:0}, 200);
}
function formatNumber(num) {
	num = String(num).split(".");
	num[0] = (num[0] || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
	if(num[1]){
		num = num[0]+'.'+num[1];
	}else{
		num = num[0]
	}
    
	return num
}
function formatNumberAsForeigner(num, point) {
	point = point ? point : 0;
	var str = parseFloat(num) + '';
	var len = str.length;
	var newNumberStr = 0;
	if(len <= 3) {
	    newNumberStr = str;
	} else if (len <= 6) {
	    point = str.substr(len-3, point);
	    newNumberStr = str.substr(0, len-3) + (point ? '.' + point : '') + 'K';
	} else if (len <= 9) {
	    point = str.substr(len-6, point);
	    newNumberStr = str.substr(0, len-6) + (point ? '.' + point : '') + 'M';
	} else if (len <= 12) {
	    point = str.substr(len-9, point);
	    newNumberStr = str.substr(0, len-9) + (point ? '.' + point : '') + 'G';
	} else{
	    point = str.substr(len-12, point);
	    newNumberStr = str.substr(0, len-12) + (point ? '.' + point : '') + 'T';
	}
	return newNumberStr;
}


function cartReady(){
	$.mamall_request('video.cart.check', {
		OM_DEVICE_UUID: api.deviceId
	}, function(r) {
		if('9999' == r.ErrorCode) {
			if(r.Data){
				$api.setStorage("cart",'true');
			}else{
				$api.setStorage("cart","false");
			}
			setTimeout(function(){
				cartActive($api.getStorage("cart"));
			},100);
		}
	},"",api);
	
	api.addEventListener({
	    name: 'cartListener'
	}, function(ret, err) {
		cartActive(ret.value.Key); 
	});
	
}
function cartActive(on){
	if(on==="true"){
		$(".nui-header-item .icon-gouwuche").addClass("active");
		$(".bottom-button-group [data-type='cart']").addClass("active");
	}else{
		$(".nui-header-item .icon-gouwuche").removeClass("active");
		$(".bottom-button-group [data-type='cart']").removeClass("active");
	}
}
//rate app
function showThisVerRate() {
	//生成评分交互
	var rateFlag = localStorage.getItem("HAS_RATE_ALREADY");
	if((! rateFlag) && getCId()) {
		var lastTimeCheckRate = localStorage.getItem("LAST_TIME_CHECK_RATE");
		var d = new Date();
		var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(lastTimeCheckRate && lastTimeCheckRate != today) {
			//不是当天下载的新用户
			var thisVerCloseFlag = localStorage.getItem("RATE_CLOSED_VER_" + api.appVersion);
			if((! thisVerCloseFlag)) {
				//找到页面元素，显示html评分提示
			}
		}
		if(lastTimeCheckRate == null) {
			localStorage.setItem("LAST_TIME_CHECK_RATE", today);
		}
	}
}
function hideThisVerRate(rated) {
	//本版本不再显示或者已经评过分，隐藏当前提示评分模块
	//隐藏html
	/*
	hide dom
	*/

	//当前版本不再显示提醒
	localStorage.setItem("RATE_CLOSED_VER_" + api.appVersion, true);
	//所有版本不再显示提醒
	if(rated == true) {
		//已前去打过分，不再显示打分模块
		localStorage.setItem("HAS_RATE_ALREADY", true);
	}
}
function ratingReturn(type){
 	switch(type){
 		case 'notreally':
 			$(".rating-box p").text('Would you mind giving us some feedback?');
 			$(".rating-box .action a").not(".confirm").text('No,thanks').prop('href','javascript:ratingReturn("no");');
 			$(".rating-box .action a.confirm").text("Ok,sure").prop('href','javascript:ratingReturn("feedback");');
 			break;
 		case 'yes':
 			$(".rating-box p").text('How about a rating on the App Store,then?');
 			$(".rating-box .action a").not(".confirm").text('No,thanks').prop('href','javascript:ratingReturn("no");');
 			$(".rating-box .action a.confirm").text("Ok,sure").prop('href','javascript:ratingReturn("rating");');
 			break;
 		case 'feedback':
 			$(".rating-box p").text('Feedback');
 			$(".rating-box .action").hide().after('<div class="fb-box">\
														<textarea placeholder="Please help us perfect service for you"></textarea>\
														<div class="fb-action">\
															<a href="javascript:ratingRemove();">Cancel</a>\
															<a href="javascript:feedbackSubmit();" class="confirm">Submit</a>\
														</div>\
													</div>');
 			break;
 		case 'rating':
 			var rateUrl = '';
 			if(api.systemType == 'ios') {
 				rateUrl = 'http://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=1133962714&pageNumber=0&sortOrdering=2&type=Purple+Software&mt=8';
 			} else {
 				rateUrl = 'market://details?id=com.ourmall';
 			}
   			window.location.href = rateUrl;
			localStorage.setItem("HAS_RATE_ALREADY", true);
 			ratingRemove();
 			break;	
 		case 'no':
 			ratingRemove();
 			break;	
 	}
}
function ratingCreat(_tagName){
	//生成评分交互
	var ratingBox = '';
	var rateFlag = localStorage.getItem("HAS_RATE_ALREADY");
	if((! rateFlag) && getCId()) {
		var lastTimeCheckRate = localStorage.getItem("LAST_TIME_CHECK_RATE");
		var d = new Date();
		var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(lastTimeCheckRate && lastTimeCheckRate != today) {
			//不是当天下载的新用户
			var thisVerCloseFlag = localStorage.getItem("RATE_CLOSED_VER_" + api.appVersion);
			if((! thisVerCloseFlag)) {
				//当前版本没有点过关闭评分提示
				if(!_tagName){
			 		_tagName = 'section';
			 	}
			 	//创建提示
			 	ratingBox = '<'+_tagName+' data-box="rating">\
								<div class="rating-box">\
									<p>Enjoying OurMall APP?</p>\
									<div class="action">\
										<a href="javascript:ratingReturn(\'notreally\');">Not really</a>\
										<a class="confirm" href="javascript:ratingReturn(\'yes\');">Yes!</a>\
									</div>\
								</div>\
							</'+_tagName+'>';
			}
		}
		if(lastTimeCheckRate == null) {
			//新用户，第一次监测，把监测日期设置为今天
			localStorage.setItem("LAST_TIME_CHECK_RATE", today);
		}
	}
	return ratingBox;
}
function ratingRemove(){
 	//提示框消失
 	localStorage.setItem("RATE_CLOSED_VER_" + api.appVersion, true);//当前版本不再提醒
	$(".rating-box").parent().fadeOut(200);
	setTimeout(function(){
		$(".rating-box").remove();
	},200);
}
function feedbackSubmit(){
 	var text = $(".rating-box textarea").val();
 	if(text!=""){
 		$.mamall_request('feedback.insert', {
			customerId: getCId(),
			content:text
		}, function(r) {
			nui.toast('Thank you for your feedback!');
			localStorage.setItem("HAS_RATE_ALREADY", true);
			ratingRemove();
		},"",api);
 	}else{
		nui.toast('Please enter a comment.');
 	}
}
function gotoOurMallWeb(url, name) {
	name = name ? name : '';
	if(sysType == 'ios') {
		var type = 2;
	} else {
		var type = 1;
	}
	var sysType = api.systemType;
	var jpId = localStorage.getItem("OURMALL_RGID")?localStorage.getItem("OURMALL_RGID"):"";
	if(! getCId()) {
		$api.setStorage('LAST_PAGE_BEFORE_LOGIN', {type:'OurMallWeb', name:name, url:url});
	}
	var redirectUrl = hostURL() + "?m=main&a=redirectFromApp&hideH5Menu=1&hideH5MenuFromNewApp=1&mPlatform=" + type + "&jpushCode=" + jpId + "&OM_DEVICE_UUID=" + api.deviceId;
	url = redirectUrl + '&redirectUrl=' + encodeURIComponent(url);
	api.openWin({
		name: "OurMallWeb_" + name.replace(/ /g, '_'),// + '_' + Math.random(),
		url: "widget://html/product/webpage.html",
		pageParam: {_url:url,name:name},//这里是要打开的网址
		animation: {
			type: "movein",
			subType: "from_right"
		},
		reload: true,
		slidBackEnabled: false
	});
}
function hostURL(){
    var host = '';
    var HTTP_HEADER = '';
    if(api.debug == true) {
        HTTP_HEADER = 'http';
		host = HTTP_HEADER + '://sandbox.video.ourmall.com/index.php';
    }else{
		HTTP_HEADER = 'https';
		host = HTTP_HEADER + '://video.ourmall.com/index.php';
	}
    return host;
}
function openFrameReload(index,type){
	if(!type){
		type = "mall"
	}
	api.setFrameGroupIndex({
		name: type+'Group',
		index: index,
		scroll: true,
		reload:true	
	});
}
//pay success
function paySuccess(){
	api.execScript({
		name: 'my-orders',
		script:'api.closeFrameGroup({name: "my-orders-group"})'
	});
	api.openWin({
		name:'my-orders',
		url : 'widget://html/account/my-orders.html',
			animation: {
				type: "movein",
				subType: "from_right"
			},
		reload:true,	
		pageParam:{
			status:0
		}
	});
	setTimeout(function(){		
		api.closeWin({
		    name: 'order-confirm',
		    animation:{
		    	type:'none'
		    }
		});
		api.closeWin({
		    name: 'order-detail',
		    animation:{
		    	type:'none'
		    }
		});
	},500);		
}
function startPaypal(totalPrice,paymentOrderCode){
	var paypal = api.require('paypal');
	if(typeof payMask != 'function'){
		payMask = function(){
			api.execScript({
			    name: 'main',
			    script: 'paySuccess()'
			});	
		}
	}
	paypal.pay({
	     currency: 'USD',
	     price: totalPrice,
	     description: 'OurMall Order NO: ' + paymentOrderCode,
	     mode: api.debug == true ? 'sandbox' : 'production' // production  sandbox  noNetwork
	}, function(ret) {
	 	if(ret && ret.state == 'success') {
	 	    $.mamall_request('video.order.executepayment',{paymentId:ret.response.id, type:1, orderCode:paymentOrderCode}, function(r) {
	 			if('9999' == r.ErrorCode) {
	 				//日志
					var logJson = new Object;
					logJson.orderId = paymentOrderCode.split(",");
					appLog(7,logJson);
					
	 				payMask('success');
				} else {
	 				payMask('failed');
	 			}
				setTimeout(function(){
	 					api.execScript({
						    name: 'main',
						    script: 'paySuccess()'
						});	
	 				},3250);
	 		},undefined,api);
	 	}else{
	 		payMask('failed');
	 		setTimeout(function(){
					api.execScript({
				    name: 'main',
				    script: 'paySuccess()'
				});	
			},2000);
	 	}
    });
}

function startPayssion(customerId,paymentData){
	var jsonOrderCodeData = new Object; 
	var paymentData2 = new Object;
	for(var i in paymentData){
		jsonOrderCodeData[i] = new Object;
	}
	for (var j in jsonOrderCodeData){
		jsonOrderCodeData[j].goodsAmount = paymentData[j].goodsAmount
		jsonOrderCodeData[j].shippingAmount = paymentData[j].shippingAmount
		jsonOrderCodeData[j].couponAmount = paymentData[j].couponAmount
	}
	paymentData2.customerId = customerId;
	paymentData2.jsonOrderCode = JSON.stringify(jsonOrderCodeData)
	
	$.mamall_request('order.getpayurl',paymentData2, function(r) {
		if(r.ErrorCode == '9999') {
			var pay2Url = r.Data.payUrl;
			api.openWin({
				name: "payssion",
				url: "widget://html/product/webpage.html",
				pageParam: {_url:pay2Url,name:'Pay Order'},//这里是要打开的网址
				animation: {
					type: "movein",
					subType: "from_right"
				},
				reload: true,
				slidBackEnabled: false
			});
		} else {
			nui.toast(r.Message);
			api.sendEvent({
			    name: 'cancelPay'
			});
		}
	},undefined,api);
}

function cardPayReturn(type,msg){
	switch(type){
		case 'success':
			payMask('success');
			setTimeout(function(){
				api.execScript({
				    name: 'main',
				    script: 'paySuccess()'
				});	
			},3250);		
		break;
		case 'failed':
			payMask('failed',msg.trim() ? msg.trim() : 'Failed');
		    setTimeout(function(){
				api.execScript({
				    name: 'main',
				    script: 'paySuccess()'
				});	
			},2000);
		break;
	}
}
function callAppPage(appParam) {
	if(appParam) {
		appParam = JSON.parse(appParam);
		if(appParam && appParam.type) {
			switch(appParam.type) {
		    	case 'video': // 视频详情
					var vid = appParam.vid;
					var pid = appParam.pid;
					if(vid && pid) {
						openDetail(vid, pid);
					} 
					break;

				case 'vlogger': // 红人主页
					var cid = appParam.cid;
					var pid = appParam.pid;
					if(cid && pid) {
						openUsersDetail(pid, cid);
					} 
					break;
				
				case 'product': // 商品详情
					var isOurmall = appParam.isOurmall;
					var pid = appParam.pid;
					var productId = appParam.productId;
					var sponsorShopId = appParam.sponsorShopId;
					if(isOurmall && ((pid) || (productId && sponsorShopId))) {
						openProDetail(isOurmall, pid, productId, sponsorShopId);
					} 
					break;

				case 'mall'://mall菜单
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuMall"), 1, true)'
					});
					break;

				case 'account'://account菜单
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuAccount"), 3, true)'
					});
					break;

				case 'show'://show列表菜单
					api.execScript({
						name:'main',
						script:'changeFrame(document.getElementById("AppMenuShow"), 4, true)'
					});
					break;

				case 'showDetail'://show详情页
					var id = appParam.id;
					if(id) {
						openShowDetail(id);
					} 
					break;

				case 'activityList'://活动列表页
					openActivityList();
					break;
				
				case 'openUrl'://webview打开链接
					gotoOurMallWeb(appParam.url, 'OurMall');
					break;
				
				case 'channelUser':
					//记录渠道用户标记，用于关联新用户与渠道id之间的关系
					$api.setStorage('channelId',appParam.channelId);
					break;
	    	}
	    }
	}
}

//打开付款遮罩
function payMask(type,msg){
	if(!type){
		$("body").append('<div class="pay-wait-mask">\
			<div class="pay-wait-inner">\
				<p>Payment in processing…</p>\
				<div style="position: relative;">\
					<div class="loader"></div>\
					<div class="sa-icon sa-success animate" style="display: none;">\
				      <span class="sa-line sa-tip "></span>\
				      <span class="sa-line sa-long "></span>\
				    </div>\
				    <div class="sa-icon sa-error animateErrorIcon" style="display: none;">\
				      <span class="sa-x-mark animateXMark">\
				        <span class="sa-line sa-left"></span>\
				        <span class="sa-line sa-right"></span>\
				      </span>\
				    </div>\
				</div>\
			</div>\
		</div>')
		$(".pay-wait-mask").show();
		return;
	}
	switch(type){
		case 'success':
			$(".pay-wait-mask").addClass('active');
			$(".pay-wait-inner p").text('Paid Successfully');
			$(".sa-line").css("opacity",0);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-bottom-color","transparent");
			},500);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-left-color","transparent");
			},600);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-top-color","transparent");
				$(".sa-success").show();
				$(".sa-tip").addClass("animateSuccessTip").css("opacity",1);
			},700);
			setTimeout(function(){
				$(".sa-long").addClass("animateSuccessLong").css("opacity",1);
			},1450);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css({
					'border-bottom-color':"#A5DC86",
					'border-left-color':"#A5DC86",
					'border-top-color':"#A5DC86",
					'border-right-color':"#A5DC86",
					'opacity':".3"
				});
			},2300)
		break;
		case 'failed':
			$(".pay-wait-mask").addClass('active');
			$(".pay-wait-inner p").text(msg ? msg:'Payment Canceled').css("color",'#E62117');
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-bottom-color","transparent");
			},500);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("border-left-color","transparent");
			},600);
			setTimeout(function(){
				$(".pay-wait-mask .loader").css("opacity",0);	
			},700);
			setTimeout(function(){
				$(".sa-error").show();
				$(".sa-x-mark").addClass("animateXMark");
			},1200);
			
		break;
	}
}
function getLocalTime(nS) {       
    return  new Date(parseInt(nS) * 1000).Format("MM-dd-yyyy hh:mm");    
 } 
function formatTime(nS){
	var time = new Date(parseInt(nS) * 1000).Format("MM-dd-yyyy").split('-'); 
	var MM = time.shift();
	switch (MM)
	{
		case '01':
			MM = 'Jan'
		break;
		case '02':
			MM = 'Feb'
		break;
		case '03':
			MM = 'Mar'
		break;
		case '04':
			MM = 'Apr'
		break;
		case '05':
			MM = 'May'
		break;
		case '06':
			MM = 'Jun'
		break;
		case '07':
			MM = 'Jul'
		break;
		case '08':
			MM = 'Aug'
		break;
		case '09':
			MM = 'Sep'
		break;
		case '10':
			MM = 'Oct'
		break;
		case '11':
			MM = 'Nov'
		break;
		case '12':
			MM = 'Dec'
		break;
	}
	return MM+' '+time[0]+' '+time[1]
}
Date.prototype.Format = function (fmt) { //author: meizz   
        var o = {  
            "M+": this.getMonth() + 1, //月份   
            "d+": this.getDate(), //日   
            "h+": this.getHours(), //小时   
            "m+": this.getMinutes(), //分   
            "s+": this.getSeconds(), //秒   
            "q+": Math.floor((this.getMonth() + 3) / 3), //季度   
            "S": this.getMilliseconds() //毫秒   
        }; 
        
        if (/(y+)/.test(fmt)) fmt = fmt.replace(RegExp.$1, (this.getFullYear() + "").substr(4 - RegExp.$1.length));  
        for (var k in o)  
        if (new RegExp("(" + k + ")").test(fmt)) fmt = fmt.replace(RegExp.$1, (RegExp.$1.length == 1) ? (o[k]) : (("00" + o[k]).substr(("" + o[k]).length)));  
        return fmt;  
    }
//是否空对象
function isEmptyObject(e) {  
    var t;  
    for (t in e)  
        return !1;  
    return !0  
} 
//日志
function appLog(Type,Json){
	var userInfo = JSON.parse(localStorage.getItem("OURMALL_USERINFO"));
	if(isEmptyObject(userInfo)) return;
	var CustomerId = userInfo.customerId;
	$.mamall_request('a:log.Log.insert',{
			type:Type,
			otherId:CustomerId,
			operationJson:JSON.stringify(Json)
	}, function() {},undefined,api);
}
//数组去重
function unique(array){ 
	var r = []; 
	for(var i = 0, l = array.length; i < l; i++) { 
		for(var j = i + 1; j < l; j++) 
			if (array[i] === array[j]) j = ++i; 
		r.push(array[i]); 
	} 
	return r; 
}
function saveLocalPageData(key, data, page, totalPage) {
	var saveData = {};
	var timestamp = Date.parse(new Date());
	timestamp = timestamp / 1000;
	saveData.html = data;
	saveData.timestamp = timestamp;
	saveData.page = page;
	saveData.totalPage = totalPage;
	key = 'PAGE_CACHE_DATA_' + key;
	
	$api.setStorage(key, saveData);
	return true;
}
function getLocalPageData(key) {
	key = 'PAGE_CACHE_DATA_' + key;
	return $api.getStorage(key);
}
function removeLocalPageData(key) {
	key = 'PAGE_CACHE_DATA_' + key;
	$api.rmStorage(key);
	return true;
}
filterBadge = function(type,cid){
	if(!cid || cid == 9998 || cid == 9999){
		filterBadgeActive(false,type)
		return;
	}
	if(type){
		var mallFilter = JSON.parse($api.getStorage('MallProductCategoryFilter'));
		var showFilter = JSON.parse($api.getStorage('ShowProductCategoryFilter'));
	}else{
		return false;
	}
	if(type == 'mall'){
		if(mallFilter[cid].nameLike || mallFilter[cid].minPrice || mallFilter[cid].maxPrice || mallFilter[cid].sortBy){
			filterBadgeActive(true,'mall')
		}else{
			filterBadgeActive(false,'mall')
		}
	}else if('show'){
		if(showFilter[cid].nameLike || showFilter[cid].sortBy){
			filterBadgeActive(true,'show')
		}else{
			filterBadgeActive(false,'show')
		}
		
	}else{
		return false;
	}	
}
filterBadgeActive = function(on_off,type){
	on_off = on_off ? 'addClass':'removeClass';
	if(type == 'mall'){
		eval('$(".header-container .right-btns .icon0-filter[title=mall] .badge").'+on_off+'("active")');
	}else if(type == 'show'){
		eval('$(".header-container .right-btns .icon0-filter[title=show] .badge").'+on_off+'("active")');
	}else{
		eval('$(".header-container .right-btns .icon0-filter[title=show] .badge").'+on_off+'("active")');
	}
	
}
function in_array(val, arr) {
	for(var i = 0; i < arr.length; i ++) {
		if(arr[i] == val) {
			return true;
		}
	}
	return false;
}

function getBannerStatus() {
	$.mamall_request('video.account.bannerstatus',{ }, function(r) {
		if('9999' == r.ErrorCode) {
			$api.setStorage('APP_BANNER_STATUS', r.Data);
		}
	},undefined,api);
}

function creatPop(){
	api.openFrame({
		name: 'pop-mask',
		url: 'widget://html/pop/pop-mask.html',
		bounces: false,
		bgColor: 'rgba(0,0,0,.7)',
		vScrollBarEnabled: false,
		hScrollBarEnabled: false
	});
	$('li.pop-switch').remove();
	api.addEventListener({
	    name: 'removePop'
	}, function(ret, err) {
		api.closeFrame({
		    name: 'pop-mask'
		});
	    $('li.pop-switch').remove();
	    clearInterval(rotateTime);
	    creatOpenPopSide();
	    $api.setStorage("popState",'hide');
	});
}
var rotateTime;
function creatOpenPopSide(){
	var Htmls = '<li class="pop-switch shake-rotate" onclick="creatPop();"><img src="../../image/pop-swith-bg.png"></li>';
	$(".button-menu").prepend(Htmls);
	setTimeout(function(){
		shakeRotate();
	},3000)
	rotateTime = setInterval(function(){
		shakeRotate();
	},11000)
}
function removePop(){
	api.sendEvent({
	    name: 'removePop'
	});
}
function startPop(){
	var popState = $api.getStorage("popState");
	if(popState == 'hide'){
		creatOpenPopSide();
	}else{
		creatPop();
	}
	
};
function shakeRotate(){
	$('.pop-switch.shake-rotate').addClass('active');
	setTimeout(function(){
			$('.pop-switch.shake-rotate').removeClass('active');
		},1000);
}
function imgWH(el){
	var Img = new Image(),
		_src = $(el).prop('src');
	Img.src = _src;
	Img.onload = function(){
		var imgW = el.width,
			imgH = el.height;
		if(imgW>=imgH){
			$(el).height(70).width('auto');
		}else{
			$(el).width(70).height('auto');
		}	
	}
}
function autocompleActive(_switch){
	if(_switch){
		$('.search-comple').show();
		$('#wrap').hide();
	}else{
		$('.search-comple').hide();
		$('#wrap').show();
	}
	
}
