function AROpenFun() {
	openDetail = function(vid, pid) {
		$api.openWin({
	        name: 'detail',
	        url: "widget://html/product/detail.html",
	        pageParam: {vid:vid,pid:pid},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	var proIdArr;
	openProDetail = function(type,_pid,_tpid,_sid) {
	switch($api.getStorage('activeMainMenu')){
		case 'mall':
		//沉浸式状态栏
		if(api.systemType=="ios"){
            if(parseInt(api.systemVersion,10)>=7){
               api.addEventListener({
				    name:'viewappear'
				}, function(ret, err){
					setTimeout(function(){
						api.setStatusBarStyle({
						    style: 'light',
						    color:'transparent'
						});
					},200);
				});
           }
    	}
		break;
	}
		if(type == '4'){
			$api.openWin({
				name: 'pro-detail-give',
				url: "widget://html/product/pro-detail-give.html",
				pageParam: {_id:_tpid,_pid:_pid,_sid:_sid},//这里是要打开的网址
				animation: {
					type: "movein",
					subType: "from_right"
				},
				reload: true
			});
			return;
		}

		if(!!_tpid && !!_sid){
			var proId = {};
			proId[_tpid+'_'+_sid] = 1;
			if(!localStorage.getItem('RV-Key')){
				localStorage.setItem('RV-Key','[]');
			}
			var proIdArr = JSON.parse(localStorage.getItem('RV-Key'));
			if(!Object.prototype.toString.call(proIdArr) === '[object Array]'){
				proIdArr = new Array;
			}
			for( var i=0; proIdArr.length>i;i++ ){

				for(var obj in proIdArr[i]){
					if(obj == _tpid+'_'+_sid){
						oldProId = proIdArr[i];
						proId[_tpid+'_'+_sid] = proIdArr[i][_tpid+'_'+_sid] +1;
						proIdArr.splice(i, 1);
						break;
					}
				}
			}
			proIdArr.push(proId);
			//proIdArr = getArray(proIdArr);
			if(proIdArr.length>=50){
				proIdArr.shift();
			}
			//存本地
			localStorage.setItem('RV-Key',JSON.stringify(proIdArr));
			//存接口
			var localUinfo = JSON.parse(localStorage.getItem('OURMALL_USERINFO'));
			var customerId;
			if(!isEmptyObject(localUinfo)) customerId = localUinfo.customerId;
			if(customerId){
				var crvApiOption = new Object;
				crvApiOption.customerId = customerId;
				crvApiOption.plus = _tpid+'_'+_sid;
				crvApiOption.productIdJson = JSON.stringify(proIdArr);
				$.mamall_request('customer.recentlyViewed', crvApiOption, function(){},undefined,api);
			}		
		}
		if(type == '2'){
			$api.openWin({
		        name: 'pro-detail',
		        url: "widget://html/product/pro-detail.html",
		        pageParam: {_pid:_pid},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true
		    });
		} else if (type == '3') { // show详情的非ourmall商品
			$api.openWin({
		        name: 'pro-detail',
		        url: "widget://html/product/pro-detail.html",
		        pageParam: {_pid:_pid, source:'show'},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true
		    });
		}
		else{
			$api.openWin({
		        name: 'pro-detail-platform',
		        url: "widget://html/product/pro-detail-platform.html",
		        pageParam: {_pid:_tpid,_sid:_sid},//这里是要打开的网址
		        animation: {
		            type: "movein",
		            subType: "from_right"
		        },
		        reload: true
		    });
		}
	}
	openReviewList = function(reviewInfo) {
		$api.openWin({
	        name: 'pro-detail-review',
	        url: "widget://html/product/pro-detail-review.html",
	        pageParam: {reviewInfo:reviewInfo},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	openVlgReviewList = function(reviewInfo) {
		$api.openWin({
	        name: 'VloggerFeedbackList',
	        url: "widget://html/product/pro-detail-vlg-review.html",
	        pageParam: {reviewInfo:reviewInfo},//这里是要打开的网址
	        animation: {
	            type: "movein",
	            subType: "from_right"
	        },
	        reload: true
	    });
	}
	//进入give活动列表
	openGiveDetail = function(id,pid,sid,applyId) {
		$api.openWin({
			name: 'pro-detail-give',
			url: "widget://html/product/pro-detail-give.html",
			pageParam: {_id:id,_pid:pid,_sid:sid,_applyId:applyId},//这里是要打开的网址
			animation: {
				type: "movein",
				subType: "from_right"
			},
			reload: true
		});
	}
}
function getArray(a) {
 var hash = {},
     len = a.length,
     result = [];

 for (var i = 0; i < len; i++){
     if (!hash[a[i]]){
         hash[a[i]] = true;
         result.push(a[i]);
     } 
 }
 return result;
}
//打开deal详情
function openGroupDetail(_id,_pid,_sid,_gid){
	$api.openWin({
        name: 'groupbuying-detail-platform',
        url: "widget://html/product/groupbuying-detail-platform.html",
        pageParam: {
        	_id: _id,
        	_pid: _pid,
        	_sid: _sid,
        	_gid: _gid
        },
        animation: {
            type: "movein",
            subType: "from_right"
        },
        reload: true
    });
}
//打开justforyou deal详情
function openJustforyouDealDedail(_pid,_sid,_skillId){
	$api.openWin({
        name: 'pro-detail-platform',
        url: "widget://html/product/pro-detail-platform.html",
        pageParam: {_pid:_pid,_sid:_sid,_skillId:_skillId},//这里是要打开的网址
        animation: {
            type: "movein",
            subType: "from_right"
        },
        reload: true
   });
}
//打开 collection 详情
function openCollectionDetail(_id){
	$api.openWin({
		name: 'collection-detail',
		url: "widget://html/explore/collection-detail.html",
		pageParam: {id: _id},
        animation: {
            type: "movein",
            subType: "from_right"
        },
        reload: true
	})
}
//打开 justforyou-prolist 列表
function openJustforyouProlist(_id){
	$api.openWin({
		name: "justforyou-prolist",
		url: "widget://html/justforyou/justforyou-prolist.html",
		pageParam: {id: _id},
        animation: {
            type: "movein",
            subType: "from_right"
        },
        bgColor:"#fff",
		reload: true
	})
	$api.rmStorage('justforyouFilterStorage')
}
function openRecommendDetail(_id,_type){
	$api.openWin({
		name: 'recommend-detail',
		url: "widget://html/explore/recommend-detail.html",
		pageParam: {
			id: _id,
			type: _type
		},
        animation: {
            type: "movein",
            subType: "from_right"
        },
        reload: true
	})
}
