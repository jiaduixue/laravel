ARCommon = function(){
	var page = 1;
	var totalPage = "";
	var catId = api.frameName.replace(/[^0-9]/ig,"");
	var postUrl = "";
	var loadFlag = true;
	var categoryIds = 'categoryIds';
	var settledwords;
	var cacheData = null;
	var retryTimes = 0;
	switch(api.frameName){
		case (api.frameName.match(/homeGroup/) || {}).input:
			var wrapUlDom = $("#wrap");//video 容器
			postUrl = 'video.app.videolist';
			cacheData = getLocalPageData('HOME_GROUP_' + catId);
			break;
		case (api.frameName.match(/mallGroup/) || {}).input:
			var wrapUlDom = $("#wrap .mall-pro-list");//商品 容器
			if(wrapUlDom.length==0){
				$("#wrap").html('<ul class="mall-pro-list"></ul>');
				wrapUlDom = $("#wrap .mall-pro-list");
			}
			postUrl = 'product.productlist';
			cacheData = getLocalPageData('MALL_GROUP_' + catId);
			break;
		default:
			break;
	}
	function shareExpire(){
		$("[data-expiretime]").each(function(){
			var expiretime = $(this).attr("[data-expiretime]");
			if(expiretime < Date.parse(new Date()) / 1000){
				$(this).find('.share-badge-warp').hide();
			}
		});
	}
	
	nui.pullrefresh(function(){
		if($('.pulldownload').is(':visible') || !loadFlag){
			return false;
		}
		page = 1;
		cacheData = null;
		if(postUrl == 'video.app.videolist') {
			removeLocalPageData('HOME_GROUP_' + catId);
			getList();
		} else {
			removeLocalPageData('MALL_GROUP_' + catId);
			if (catId == 9999) {
				getRecentlyList();
			} else if (catId == 9998) {
				getLastestList();
			} else if (catId == 9997){
				getGiveAwayList();
			} else{
				getSettledwords();
			}
		}
	},'#f6f6f6')
	
	nui.pullAppend(function(){
		if($('.pulldownload').is(':visible') || !loadFlag){
			return false;
		}
		if(catId == 9999){
			if(page >= totalPage ) {
				$('.pulldownload').hide();
				nui.toast($.i18n.prop("No more data"));
				return;
			}
			getRecentlyList("append");
		} else if(catId == 9998){
			if(page >= totalPage ) {
				$('.pulldownload').hide();
				nui.toast($.i18n.prop("No more data"));
				return;
			}
			getLastestList("append");
		} else if(catId == 9997){
			if(page >= totalPage ) {
				$('.pulldownload').hide();
				nui.toast($.i18n.prop("No more data"));
				return;
			}
			getGiveAwayList("append");
		} else{
			if(page >= totalPage ) {
				$('.pulldownload').hide();
				nui.toast($.i18n.prop("No more data"));
				return;
			}
			getList("append");
		}
	});
	
	getList = function(type){
		if(!loadFlag){
			return false;
		}
		loadFlag = false;
		$('.pulldownload').show();
		var apiOption = {
			categoryIds:catId,
			page:type == "append" ? page + 1 : page,
			rowsPerPage:10
		};
		if(postUrl == 'product.productlist'){
			var tmpKeywords = ''; 
			if($api.getStorage('MallProductCategoryFilter')){
				var tmpObj = $api.getStorage('MallProductCategoryFilter') ? JSON.parse($api.getStorage('MallProductCategoryFilter')) : {};
				if(typeof(tmpObj) == 'object' && typeof(tmpObj[catId]) == 'object') {
					tmpKeywords = tmpObj[catId].nameLike;				
					if(tmpObj[catId].minPrice){
						apiOption.bonusFrom = tmpObj[catId].minPrice;
					}
					if(tmpObj[catId].maxPrice){
						apiOption.bonusTo = tmpObj[catId].maxPrice;
					}
					if(tmpObj[catId].sortBy){
						apiOption.sort = tmpObj[catId].sortBy;
					}
					if(typeof tmpObj[catId].specificsQueryCond == 'object'){
						apiOption.specificsQueryCond = '';
						for( var i = 0; i<tmpObj[catId].specificsQueryCond.length; i++){
							if(tmpObj[catId].specificsQueryCond[i] == 'All') continue;
							apiOption.specificsQueryCond += tmpObj[catId].specificsQueryCond[i] + ','
						}
						apiOption.specificsQueryCond = apiOption.specificsQueryCond.substring(0,apiOption.specificsQueryCond.length-1);
					}
				}
			}
			if(typeof(tmpObj) == 'object' && typeof(tmpObj[catId]) == 'object' && (tmpObj[catId].nameLike || apiOption.specificsQueryCond)){
				apiOption.categorytwo=tmpObj[catId].nameLike;
			} else if(page <= 2 && catId) {
				//第一、二页且有历史访问
				var RVproArr = JSON.parse(localStorage.getItem('RV-Key'));
				if(RVproArr) {
					var arrStar = 10 * ((type == "append" ? page + 1 : page)-1);
					var arrEnd = arrStar + 10;
					if(arrStar + 10 > RVproArr.length){
						arrEnd = RVproArr.length;
					}
					var thisArr = RVproArr.slice(arrStar,arrEnd);
					apiOption.recentlyViewed = RVArrFormat(thisArr);
				}
			} else {
				apiOption.settledwords=settledwords;
			}
			apiOption.categoryId=catId;
		}
		if(!apiOption.nameLike) delete apiOption.nameLike;
		if(! settledwords) { delete apiOption.settledwords; }
		$.mamall_request(postUrl,apiOption, function(r) {
			loadFlag = true;
			if('9999' == r.ErrorCode) {
				$('.pulldownload').hide();
				retryTimes = 0;
				var listJson = r.Data;
				if(listJson) {
					if(listJson.Pagination)
						totalPage = listJson.Pagination.totalpage;
					if(type == "append"){
						$(wrapUlDom).append(baidu.template("listTemp",listJson));
						page += 1;
					}else{
						if(postUrl == 'product.productlist' && listJson.marketList.length == 0){
							$(wrapUlDom).html(baidu.template("listTemp",{marketList:'NoData'}));
						}else{
							$(wrapUlDom).html(baidu.template("listTemp",listJson));
						}
					}
					if(page == 1) {
						//第一页最后追加评分模块
						if(postUrl == 'video.app.videolist' && catId == 11) {
							$("#wrap").append(ratingCreat());
						}
					}
				}
				if(postUrl == 'product.productlist') {
					saveLocalPageData('MALL_GROUP_' + catId, $("#wrap").html(), page, totalPage);
				} else if(postUrl == 'video.app.videolist') {
					saveLocalPageData('HOME_GROUP_' + catId, $("#wrap").html(), page, totalPage);
				}
				imgLoad();
			}else if(r=='timeout' && retryTimes < 2){
				retryTimes ++;
				getList(type);
			}
			shareExpire();
		},undefined,api);
	}
	getRecentlyList = function(type){
		if(!loadFlag){
			return false;
		}
		loadFlag = false;
		$('.pulldownload').show();
		
		var RVproArr = JSON.parse(localStorage.getItem('RV-Key'));
		if(false) {
		//if(1) {
			//初始化首次启动商品第一个标签的数据，配合mallGroup.html使用
			RVproArr = [
						{"427596_1001117":1},
						{"286401_1001117":1},
						{"408873_1001117":1},
						{"422340_1001117":1},
						{"300612_1001117":1},
						{"353152_1001117":1},
						{"347887_1001117":1},
						{"324261_1001117":1},
						{"494700_1001117":1},
						{"325565_1001117":1}
						]
		}
		
		if(!RVproArr){
			$(wrapUlDom).html(baidu.template("listTemp",{marketList:'NoData'}));
			api.refreshHeaderLoadDone();
			$('.pulldownload').hide();
			loadFlag = true;
			return
		}

		var arrEnd = RVproArr.length-((type == "append" ? page + 1 : page)-1)*10;
		var arrStar = arrEnd-10
		if(arrStar<0){
			arrStar = 0;
		}
		
		var thisArr = RVproArr.slice(arrStar,arrEnd);
		var apiOption = {
			recentlyViewed: RVArrFormat(thisArr),
		};
		$.mamall_request('product.customerproducts', apiOption, function(r) {
			loadFlag = true;
			if('9999' == r.ErrorCode) {
				$('.pulldownload').hide();
				retryTimes = 0;
				var listJson = r.Data;
				if(listJson) {
					totalPage = Math.ceil(RVproArr.length/10);
					if(type == "append"){
						page ++;
					} else {
						$(wrapUlDom).html('');	
					}
					$(wrapUlDom).append(baidu.template("listTemp",listJson));
				}
				imgLoad();
				saveLocalPageData('MALL_GROUP_9999', $("#wrap").html(), page, totalPage);
			}else if(r=='timeout' && retryTimes < 2){
				retryTimes ++;
				getRecentlyList(type);
			}
			shareExpire();
		},undefined,api);
	}
	getLastestList = function(type){
		if(!loadFlag){
			return false;
		}
		loadFlag = false;
		$('.pulldownload').show();
		var RVproArr = JSON.parse(localStorage.getItem('RV-Key'));
		var apiOption = {page:type == "append" ? page + 1 : page};
		if(RVproArr){
			apiOption['recentlyViewed'] = RVArrFormat(RVproArr);
		}
		$.mamall_request('product.latestproducts', apiOption, function(r) {
			loadFlag = true;
			if('9999' == r.ErrorCode) {
				$('.pulldownload').hide();
				retryTimes = 0;
				var listJson = r.Data;
				if(listJson) {
					totalPage = listJson.Pagination.totalPage;
					if(page == 1) {
						$(wrapUlDom).append(ratingCreat('li'));
					}
					if(type == "append"){
						page ++;
					}else{
						$(wrapUlDom).html('');
					}
					$(wrapUlDom).append(baidu.template("listTemp",listJson));
				}
				saveLocalPageData('MALL_GROUP_9998', $("#wrap").html(), page, totalPage);
				imgLoad();
			}else if(r=='timeout' && retryTimes < 2){
				retryTimes ++;
				getLastestList(type);
			}
			shareExpire();
		},undefined,api);
	}
	getGiveAwayList = function(type){
		if(!loadFlag){
			return false;
		}
		loadFlag = false;
		$('.pulldownload').show();
		var RVproArr = JSON.parse(localStorage.getItem('RV-Key'));
		var apiOption = {page:type == "append" ? page + 1 : page};
		$.mamall_request('product.giveaway', apiOption, function(r) {
			loadFlag = true;
			if('9999' == r.ErrorCode) {
				$('.pulldownload').hide();
				retryTimes = 0;
				var listJson = r.Data;
				if(listJson) {
					totalPage = listJson.Pagination.totalPage;
					if(page == 1 && typeof(type) == 'undefined') {
						$("#wrap .free-top").remove();
						$('<div class="free-top" tapmode onclick="openReadMore();"><p>' + $.i18n.prop("Invite 2 friends, Win giveaway") + '</p><div class="top-right"><span>GO<i class="iconfont icon-jiantou"></i></span></div></div>').insertBefore('#wrap ul');
					}
					if(type == "append"){
						page ++;
					}else{
						$(wrapUlDom).html('');
					}
					$(wrapUlDom).append(baidu.template("listTemp",listJson));
				}
				saveLocalPageData('MALL_GROUP_9997', $("#wrap").html(), page, totalPage);
				imgLoad();
			}else if(r=='timeout' && retryTimes < 2){
				retryTimes ++;
				getGiveAwayList(type);
			}
		},undefined,api);
	}

	getTime = function(str){
		var _second = parseInt(str);
		var second = _second % 60 +"";
		var minute = (_second - second) / 60 +"";
		minute = minute.length == 1?"0"+minute:minute;
		second = second.length == 1?"0"+second:second;
		return minute + ":" + second;
	}
	
	function getSettledwords() {
		$.mamall_request('product.generatewords',{categoryId:catId}, function(r) {
			if('9999' == r.ErrorCode) {
				settledwords = r.Data.settledwords;	
			}
			getList();
		},undefined,api);
	}

	if(cacheData) {
		var nowTimestamp = Date.parse(new Date());
		nowTimestamp = nowTimestamp / 1000;
		if((nowTimestamp - cacheData.timestamp <= 43200)) {
			loadFlag = true;
			totalPage = cacheData.totalPage;
			page = cacheData.page;
			$('.pulldownload').hide();
		} else {
			api.refreshHeaderLoading();
		}
	} else {
		if(catId == 9999){
			getRecentlyList();
		} else if(catId == 9998) {
			getLastestList();
		}else if(catId == 9997) {
			getGiveAwayList();
		}else if ('product.productlist' == postUrl){
			var filterString = $api.getStorage('MallProductCategoryFilter');
			getSettledwords(filterString);
		} else {
			getList();
		}
	}
	
	
	function RVArrFormat(arr){
		arr = JSON.stringify(arr);
		arr = arr.substr(1);
		arr = arr.substr(0,arr.length-1);
		arr = arr.replace(/},{/g,",");
		return arr;
	}
}

