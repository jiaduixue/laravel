function AROpenFun() {
	openDetail = function(vid, pid) {
		var pageName = "";
		if(api.winName == 'detail'){
			pageName = vid + Math.random();
		}
		nui.openwindow({
			_url: "widget://html/product/detail",
			_namePrefix:pageName,
			_aniType: "movein",
			_aniSubType: "from_right",
			para: {
				vid: vid,
				pid: pid
			}
		})
	}
	openUsersDetail = function(pid, cid) {
		nui.openwindow({
			_url: "widget://html/product/user-detail",
			_aniType: "movein",
			_aniSubType: "from_right",
			para: {
				pid: pid,
				cid: cid
			}
		})
	}
	var proIdArr;
	//localStorage.removeItem('RV-Key');
	openProDetail = function(type,_pid,_tpid,_sid) {	
		if(!!_tpid && !!_sid){
			var proId = {};
			proId[_tpid+'_'+_sid] = 1;
			if(!localStorage.getItem('RV-Key')){
				localStorage.setItem('RV-Key','[]');
			}
			var proIdArr = JSON.parse(localStorage.getItem('RV-Key'));
			if(!Object.prototype.toString.call(proIdArr) === '[object Array]'){
				proIdArr = new Array;
			}
			for( var i=0; proIdArr.length>i;i++ ){
				
				if(typeof proIdArr[i] != 'object'){//老数据升级新数据
					var _oldpid = proIdArr[i];
					proIdArr[i] = {};
					proIdArr[i][_oldpid] = 1;
				}
				for(var obj in proIdArr[i]){
					if(obj == _tpid+'_'+_sid){
						oldProId = proIdArr[i];
						proId[_tpid+'_'+_sid] = proIdArr[i][_tpid+'_'+_sid] +1;
						proIdArr.splice(i, 1);
						break;
					}
				}
			}
			proIdArr.push(proId);
			//proIdArr = getArray(proIdArr);
			if(proIdArr.length>=50){
				proIdArr.shift();
			}
			//存本地
			localStorage.setItem('RV-Key',JSON.stringify(proIdArr));
			//localStorage.removeItem('RV-Key',JSON.stringify(proIdArr));
			//存接口
			var localUinfo = JSON.parse(localStorage.getItem('OURMALL_USERINFO'));
			var customerId;
			if(!isEmptyObject(localUinfo)) customerId = localUinfo.customerId;
			if(customerId){
				var crvApiOption = new Object;
				crvApiOption.customerId = customerId;
				crvApiOption.plus = _tpid+'_'+_sid;
				crvApiOption.productIdJson = JSON.stringify(proIdArr);
				$.mamall_request('customer.recentlyViewed', crvApiOption, function(){},undefined,api,10000);
			}		
		}
		if(type == '2'){
			nui.openwindow({
				_url: "widget://html/product/pro-detail",
				_aniType: "movein",
				_aniSubType: "from_right",
				para: {
					_pid: _pid,
				},
				bounces:false
			})
		}else{
			nui.openwindow({
				_url: "widget://html/product/pro-detail-platform",
				_aniType: "movein",
				_aniSubType: "from_right",
				para: {
					_pid: _tpid,
					_sid:_sid
				},
				bounces:false
			})
		}
	}
	openReviewList = function(reviewInfo) {
		nui.openwindow({
			_url: "widget://html/product/pro-detail-review",
			_aniType: "movein",
			_aniSubType: "from_right",
			para: {
				reviewInfo: reviewInfo
			}
		})

	}

	openVlgReviewList = function(reviewInfo) {
		nui.openwindow({
			_url: "widget://html/product/pro-detail-vlg-review",
			_aniType: "movein",
			_aniSubType: "from_right",
			para: {
				reviewInfo: reviewInfo
			}
		})

	}
	//打开详情
	openShowDetail = function (id,type) {
		//存rv
		var localUinfo = JSON.parse(localStorage.getItem('OURMALL_USERINFO'));
		var customerId;
		if(!isEmptyObject(localUinfo)) customerId = localUinfo.customerId;
		var apiUrl,
			apiOption = new Object,
			showId = id,
			showViewJson = localStorage.getItem('rvLast');
		if(customerId){
			apiUrl = 'a:show.Show.ourmallView';
			apiOption.customerId = customerId,
			apiOption.showId = showId;
		}else{
			apiUrl = 'a:show.Show.getOurmallViewJson';
			apiOption.showId = showId;
			if(showViewJson){
				apiOption.showViewJson = showViewJson.replace(/\\/g,'').replace('"{','{').replace('}"','}');
			}else{
				apiOption.showViewJson = '';
			}
			
		}			
		$.mamall_request(apiUrl, apiOption, function(r) {
			if (r.ErrorCode == '9999'){
				if(!customerId){
					localStorage.setItem('rvLast',JSON.stringify(r.Data))
				}
			}
		},undefined,api,10000);
		if(type){
			gotoOurMallWeb(hostURL() + '?m=show&a=showDetail&id=' + id + '&comment=' +type);
		}else{
			gotoOurMallWeb(hostURL() + '?m=show&a=showDetail&id=' + id);
		}
       	
    };
}
function getArray(a) {
 var hash = {},
     len = a.length,
     result = [];

 for (var i = 0; i < len; i++){
     if (!hash[a[i]]){
         hash[a[i]] = true;
         result.push(a[i]);
     } 
 }
 return result;
}

