//Account页面相关js方法

//my-favorites
function openMyfavorite() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'Favorite\'}');
	api.openWin({
		name: "myfavorite",
		url: "widget://html/account/my-favorites.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//contact-ourmall
function openContact() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'contactourmall\'}');
	api.openWin({
		name: "contactourmall",
		url: "widget://html/account/contact-ourmall.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//about-ourmall
function openAbout() {
	api.openWin({
		name: "aboutourmall",
		url: "widget://html/account/about-ourmall.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//privacy
function openPrivacy() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'privacy\'}');
	api.openWin({
		name: "privacy",
		url: "widget://html/account/privacy.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//openConditions
function openConditions() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'conditions\'}');
	api.openWin({
		name: "privacy",
		url: "widget://html/account/conditions.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//openfaq
function openFAQ() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'faq\'}');
	api.openWin({
		name: "privacy",
		url: "widget://html/account/faq.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//feedback
function openFeedback() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'feedback\'}');
	api.openWin({
		name: "feedback",
		url: "widget://html/account/feedback.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		bgColor:"#fff",
		reload: true
	});
}
//setting
function openSetting() {
	api.openWin({
		name: "AccountSetting",
		url: "widget://html/account/setting.html",
		animation: {
			type: "movein",
			subType: "from_right"
		},
		reload: true
	});
}
//打开订单列表
function openMyOrder(status) {
	var logJson = new Object;
	var logName ='';
	logJson.mainMenu = 'account';
	logJson.sonMenu = 'order';
	switch (status){
		case 1:
			logName ='Unpaid';
			break;
		case 2:
			logName ='Paid';
			break;
		case 3:
			logName ='Shipped';
			break;
		case 4:
			logName ='Finished';
			break;
	}
	logJson.tab = logName;
	appLog(12,logJson);
	if(!status) status = 0;
	api.openWin({
		name:'my-orders',
		url : 'widget://html/account/my-orders.html',
		animation: {
			type: "movein",
			subType: "from_right"
		},
		pageParam:{
			status:status
		},
		reload: true
	});
};
//打开地址列表
function openAddressList() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'address\'}');
    api.openWin({
        name:'address-list',
        url: 'widget://html/account/address-list.html',
        pageParam: { fromAccount:1 },
        animation:{
            type:"movein",
            subType:"from_right"
        },
        reload:true
    });
}
function languageSetting(lang) {
	lang = lang ? lang : '';
	switch(lang) {
		case 'en':
		case 'cn':
		case 'es':
			api.confirm({
			    title: $.i18n.prop("Change Language") + '?',
			    msg: $.i18n.prop("OurMall App will be restart after changing the language."),
			    buttons: [$.i18n.prop("Cancel"), $.i18n.prop("OK")]
			}, function(ret, err) {
			    var index = ret.buttonIndex;
			    if(index == 2) {
			    	localStorage.setItem('DEFAULT_APP_LANGUAGE', lang);
			    	api.showProgress({
			            style: 'default',
			            animationType: 'fade',
			            title: $.i18n.prop("Please wait..."),
			            text: '',
			        });
			    	setTimeout(function(){ api.rebootApp(); }, 1000);
			    }
			});
			break;
		default:
			var nowLanguage = localStorage.getItem('DEFAULT_APP_LANGUAGE') ? localStorage.getItem('DEFAULT_APP_LANGUAGE') : 'en';
			var buttonArray = [(nowLanguage == 'en' ? '\u2713' : '') + ' English', (nowLanguage == 'es' ? '\u2713' : '') + ' Español'];
			if(api.debug == true) {
				buttonArray.push((nowLanguage == 'cn' ? '\u2713' : '') + ' 简体中文');
			} 
			api.actionSheet({
			    title: $.i18n.prop("Change Language"),
			    cancelTitle: $.i18n.prop("Cancel"),
			    buttons: buttonArray
			}, function(ret, err) {
			    var index = ret.buttonIndex;
			    switch(index) {
			    	case 1://English
			    		if(nowLanguage != 'en') {
				    		languageSetting('en');
			    		}
			    		break;
			    	case 2://西班牙语
			    		if(nowLanguage != 'es') {
				    		languageSetting('es');
				    	}
			    		break;
			    	case 3://简体中文
			    		if(api.debug == true) {
				    		if(nowLanguage != 'cn') {
					    		languageSetting('cn');
					    	}
			    		}
			    		break;
			    	default:
			    		break;
			    }
			});
			break;
	}
	
}
//获取订单数量
function getMenuNumber(){
	if(getCId()) {
		var loadingId = '';
	    var UILoading = api.require('UILoading');
	    UILoading.flower({
	        center: {
	            x: api.winWidth / 2.0,
	            y: api.winHeight / 2.0
	        },
	        size: 40,
	        fixed: true
	    }, function(ret) {
	        loadingId = ret;
	    });

	    $.mamall_request('video.account.menunumber',{
	        OM_DEVICE_UUID:api.deviceId,
	        customerId:getCId()
	    }, function(r) {
	        if('9999' == r.ErrorCode) {
		    	var localUinfo = localStorage.getItem('OURMALL_USERINFO');
		        localUinfo = localUinfo ? JSON.parse(localUinfo) : {};
		    	if(localUinfo.channelId != r.Data.MyChannelId) {
		    		localUinfo.channelId = r.Data.MyChannelId;
		    		localStorage.setItem('OURMALL_USERINFO', JSON.stringify(localUinfo));
		    		if(localUinfo.channelId) {
		    			$api.rmStorage('CHANNEL_USER_FIRST_MASK');
		    			api.execScript({
			                name: 'main',
			                script: 'changeFrame(document.getElementById("AppMenuAccount"),3,true);'
			            }); 
			    		return;
		    		}
		    	}
	            if(loadingId) {
	                UILoading.closeFlower(loadingId);
	            }
	            $('#couponNum').text(r.Data.Coupon)//优惠券数量
	            $('#cashNum').text(r.Data.Cash)//优惠券数量
	            //订单、未读消息、Feedback、任务数量
	            for(var name in r.Data) {
	                var thisObj = r.Data[name];
	                if(name == 'Order') {
	                    for(var i in thisObj){
	                        if(thisObj[i] > 0) {
	                            $('#spanCnt' + i).html(thisObj[i]).show();
	                        }
	                    }
	                } else {
	                    if(thisObj.cnt) {
	                    	if(name != 'Feedback') {
		                        $('#spanCnt' + name).html(thisObj.cnt);
	                    	}
		                    $('#spanCnt' + name).show()
	                    }
	                }
	            }
	        }
	    }, undefined, api);
	}
}
//打开我的show列表
function openMyShowList() {
	appLog(12, '{\'mainMenu\':\'account\',\'sonMenu\':\'show\'}');
	api.openWin({
        name: 'myshow-list',
        url: "widget://html/show/myshow-list.html",
        animation: {
            type: "movein",
            subType: "from_right"
        },
        reload: true
    });
}