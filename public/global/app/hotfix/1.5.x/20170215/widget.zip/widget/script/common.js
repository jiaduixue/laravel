/*! Lazy Load 1.9.7 - MIT license - Copyright 2010-2015 Mika Tuupola */
!function(a,b,c,d){var e=a(b);a.fn.lazyload=function(f){function g(){var b=0;i.each(function(){var c=a(this);if(!j.skip_invisible||c.is(":visible"))if(a.abovethetop(this,j)||a.leftofbegin(this,j));else if(a.belowthefold(this,j)||a.rightoffold(this,j)){if(++b>j.failure_limit)return!1}else c.trigger("appear"),b=0})}var h,i=this,j={threshold:0,failure_limit:0,event:"scroll",effect:"show",container:b,data_attribute:"original",skip_invisible:!1,appear:null,load:null,placeholder:"data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAANSURBVBhXYzh8+PB/AAffA0nNPuCLAAAAAElFTkSuQmCC"};return f&&(d!==f.failurelimit&&(f.failure_limit=f.failurelimit,delete f.failurelimit),d!==f.effectspeed&&(f.effect_speed=f.effectspeed,delete f.effectspeed),a.extend(j,f)),h=j.container===d||j.container===b?e:a(j.container),0===j.event.indexOf("scroll")&&h.bind(j.event,function(){return g()}),this.each(function(){var b=this,c=a(b);b.loaded=!1,(c.attr("src")===d||c.attr("src")===!1)&&c.is("img")&&c.attr("src",j.placeholder),c.one("appear",function(){if(!this.loaded){if(j.appear){var d=i.length;j.appear.call(b,d,j)}a("<img />").bind("load",function(){var d=c.attr("data-"+j.data_attribute);c.hide(),c.is("img")?c.attr("src",d):c.css("background-image","url('"+d+"')"),c[j.effect](j.effect_speed),b.loaded=!0;var e=a.grep(i,function(a){return!a.loaded});if(i=a(e),j.load){var f=i.length;j.load.call(b,f,j)}}).attr("src",c.attr("data-"+j.data_attribute))}}),0!==j.event.indexOf("scroll")&&c.bind(j.event,function(){b.loaded||c.trigger("appear")})}),e.bind("resize",function(){g()}),/(?:iphone|ipod|ipad).*os 5/gi.test(navigator.appVersion)&&e.bind("pageshow",function(b){b.originalEvent&&b.originalEvent.persisted&&i.each(function(){a(this).trigger("appear")})}),a(c).ready(function(){g()}),this},a.belowthefold=function(c,f){var g;return g=f.container===d||f.container===b?(b.innerHeight?b.innerHeight:e.height())+e.scrollTop():a(f.container).offset().top+a(f.container).height(),g<=a(c).offset().top-f.threshold},a.rightoffold=function(c,f){var g;return g=f.container===d||f.container===b?e.width()+e.scrollLeft():a(f.container).offset().left+a(f.container).width(),g<=a(c).offset().left-f.threshold},a.abovethetop=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollTop():a(f.container).offset().top,g>=a(c).offset().top+f.threshold+a(c).height()},a.leftofbegin=function(c,f){var g;return g=f.container===d||f.container===b?e.scrollLeft():a(f.container).offset().left,g>=a(c).offset().left+f.threshold+a(c).width()},a.inviewport=function(b,c){return!(a.rightoffold(b,c)||a.leftofbegin(b,c)||a.belowthefold(b,c)||a.abovethetop(b,c))},a.extend(a.expr[":"],{"below-the-fold":function(b){return a.belowthefold(b,{threshold:0})},"above-the-top":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-screen":function(b){return a.rightoffold(b,{threshold:0})},"left-of-screen":function(b){return!a.rightoffold(b,{threshold:0})},"in-viewport":function(b){return a.inviewport(b,{threshold:0})},"above-the-fold":function(b){return!a.belowthefold(b,{threshold:0})},"right-of-fold":function(b){return a.rightoffold(b,{threshold:0})},"left-of-fold":function(b){return!a.rightoffold(b,{threshold:0})}})}(jQuery,window,document);

//lazyload
function imgLoad(){
	var option = {
		threshold: 100,
		load:function(){
			$(this).attr("data-lazyload",false);
		}
	}
	jQuery("[data-lazyload=true]").lazyload(option);
}

//rate app
function showThisVerRate() {
	//生成评分交互
	var rateFlag = localStorage.getItem("HAS_RATE_ALREADY");
	if((! rateFlag) && getCId()) {
		var lastTimeCheckRate = localStorage.getItem("LAST_TIME_CHECK_RATE");
		var d = new Date();
		var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(lastTimeCheckRate && lastTimeCheckRate != today) {
			//不是当天下载的新用户
			var thisVerCloseFlag = localStorage.getItem("RATE_CLOSED_VER_" + api.appVersion);
			if((! thisVerCloseFlag)) {
				//找到页面元素，显示html评分提示
			}
		}
		if(lastTimeCheckRate == null) {
			localStorage.setItem("LAST_TIME_CHECK_RATE", today);
		}
	}
}
function hideThisVerRate(rated) {
	//本版本不再显示或者已经评过分，隐藏当前提示评分模块
	//隐藏html
	/*
	hide dom
	*/

	//当前版本不再显示提醒
	localStorage.setItem("RATE_CLOSED_VER_" + api.appVersion, true);
	//所有版本不再显示提醒
	if(rated == true) {
		//已前去打过分，不再显示打分模块
		localStorage.setItem("HAS_RATE_ALREADY", true);
	}
}
function getCId(){
	var localUinfo = localStorage.getItem("OURMALL_USERINFO");
	localUinfo = localUinfo ? JSON.parse(localUinfo) : "";
	if(localUinfo && localUinfo.customerId){
		return localUinfo.customerId;
	}else{
		return "";
	}
}
function getUserInfo(callback) {
	var type = 0;
	if(api.systemType == 'ios') {
		type = 2;
	} else {
		type = 1;
	}
	$.mamall_request('member.getmemberbyuids', {
		mPlatform: type,
		jpushCode: localStorage.getItem("OURMALL_RGID"),
		OM_DEVICE_UUID: api.deviceId,
		H5_API_REQUEST_CACHE_SET: 2
	}, function(r) {
		if('9999' == r.ErrorCode) {
			var userData = r.Data.Customer;
			if(userData.customerId){
				localStorage.setItem("OURMALL_USERINFO",JSON.stringify(userData));
				if(typeof(callback) == 'string'){
					eval(callback);
				} else {
					callback(userData);
				}
			}else{
				api.openWin({
					name: "login",
					url: "widget://html/main/account.html",
					animation: {
						type: "movein",
						subType: "from_right",
						duration: 300,
					},
					reload: true,
					slidBackEnabled: true,
					delay: 0,
				});
			}
		}
	},"",api);
	return false;
}

function goCart(){
	api.execScript({
	    name: 'main',
	    script: 'changeFrame(document.getElementById("AppMenuCart"), 2, true);'
	});
	api.openWin({
    	name: 'main',
    	slidBackEnabled:false,
    	animation:{
	    	type:'none'
	    }
	});
	setTimeout(function(){ api.closeWin({}) }, 200);
}
function scrollToTop(){
	$('html, body').animate({scrollTop:0}, 200);
}
function formatNumber(num) {
	num = String(num).split(".");
	num[0] = (num[0] || 0).toString().replace(/(\d)(?=(?:\d{3})+$)/g, '$1,');
	if(num[1]){
		num = num[0]+'.'+num[1];
	}else{
		num = num[0]
	}
    
	return num
}
function formatNumberAsForeigner(num, point) {
	point = point ? point : 0;
	var str = parseFloat(num) + '';
	var len = str.length;
	var newNumberStr = 0;
	if(len <= 3) {
	    newNumberStr = str;
	} else if (len <= 6) {
	    point = str.substr(len-3, point);
	    newNumberStr = str.substr(0, len-3) + (point ? '.' + point : '') + 'K';
	} else if (len <= 9) {
	    point = str.substr(len-6, point);
	    newNumberStr = str.substr(0, len-6) + (point ? '.' + point : '') + 'M';
	} else if (len <= 12) {
	    point = str.substr(len-9, point);
	    newNumberStr = str.substr(0, len-9) + (point ? '.' + point : '') + 'G';
	} else{
	    point = str.substr(len-12, point);
	    newNumberStr = str.substr(0, len-12) + (point ? '.' + point : '') + 'T';
	}
	return newNumberStr;
}


function cartReady(){
	$.mamall_request('video.cart.check', {
		OM_DEVICE_UUID: api.deviceId
	}, function(r) {
		if('9999' == r.ErrorCode) {
			if(r.Data){
				$api.setStorage("cart",'true');
			}else{
				$api.setStorage("cart","false");
			}
			setTimeout(function(){
				cartActive($api.getStorage("cart"));
			},100);
		}
	},"",api);
	
	api.addEventListener({
	    name: 'cartListener'
	}, function(ret, err) {
		cartActive(ret.value.Key); 
	});
	
}
function cartActive(on){
	if(on==="true"){
		$(".nui-header-item .icon-gouwuche").addClass("active");
	}else{
		$(".nui-header-item .icon-gouwuche").removeClass("active");
	}
}

function timeoutAlert(_msg,_duration){
	if(!_msg){
		_msg = 'Request timeout, please try again!';
	}
	if(!_duration){
		_duration = 2000;
	}
	nui.toast(_msg);
}
 function ratingReturn(type){
 	switch(type){
 		case 'notreally':
 			$(".rating-box p").text('Would you mind giving us some feedback?');
 			$(".rating-box .action a").not(".confirm").text('No,thanks').prop('href','javascript:ratingReturn("no");');
 			$(".rating-box .action a.confirm").text("Ok,sure").prop('href','javascript:ratingReturn("feedback");');
 			break;
 		case 'yes':
 			$(".rating-box p").text('How about a rating on the App Store,then?');
 			$(".rating-box .action a").not(".confirm").text('No,thanks').prop('href','javascript:ratingReturn("no");');
 			$(".rating-box .action a.confirm").text("Ok,sure").prop('href','javascript:ratingReturn("rating");');
 			break;
 		case 'feedback':
 			$(".rating-box p").text('Feedback');
 			$(".rating-box .action").hide().after('<div class="fb-box">\
														<textarea placeholder="Please help us perfect service for you"></textarea>\
														<div class="fb-action">\
															<a href="javascript:ratingRemove();">Cancel</a>\
															<a href="javascript:feedbackSubmit();" class="confirm">Submit</a>\
														</div>\
													</div>');
 			break;
 		case 'rating':
 			var rateUrl = '';
 			if(api.systemType == 'ios') {
 				rateUrl = 'http://itunes.apple.com/WebObjects/MZStore.woa/wa/viewContentsUserReviews?id=1133962714&pageNumber=0&sortOrdering=2&type=Purple+Software&mt=8';
 			} else {
 				rateUrl = 'market://details?id=com.ourmall';
 			}
   			window.location.href = rateUrl;
			localStorage.setItem("HAS_RATE_ALREADY", true);
 			ratingRemove();
 			break;	
 		case 'no':
 			ratingRemove();
 			break;	
 	}
 }
 function ratingCreat(_tagName){
	//生成评分交互
	var ratingBox = '';
	var rateFlag = localStorage.getItem("HAS_RATE_ALREADY");
	if((! rateFlag) && getCId()) {
		var lastTimeCheckRate = localStorage.getItem("LAST_TIME_CHECK_RATE");
		var d = new Date();
		var today = d.getFullYear() + "-" + (d.getMonth()+1) + "-" + d.getDate();
		if(lastTimeCheckRate && lastTimeCheckRate != today) {
			//不是当天下载的新用户
			var thisVerCloseFlag = localStorage.getItem("RATE_CLOSED_VER_" + api.appVersion);
			if((! thisVerCloseFlag)) {
				//当前版本没有点过关闭评分提示

				if(!_tagName){
			 		_tagName = 'section'
			 	}
			 	//创建提示
			 	ratingBox = '<'+_tagName+' data-box="rating">\
								<div class="rating-box">\
									<p>Enjoying OurMall APP?</p>\
									<div class="action">\
										<a href="javascript:ratingReturn(\'notreally\');">Not really</a>\
										<a class="confirm" href="javascript:ratingReturn(\'yes\');">Yes!</a>\
									</div>\
								</div>\
							</'+_tagName+'>'
			}
		}
		if(lastTimeCheckRate == null) {
			//新用户，第一次监测，把监测日期设置为今天
			localStorage.setItem("LAST_TIME_CHECK_RATE", today);
		}
	}
	return ratingBox;
 }
 function ratingRemove(){
 	//提示框消失
 	localStorage.setItem("RATE_CLOSED_VER_" + api.appVersion, true);//当前版本不再提醒
	$(".rating-box").parent().fadeOut(200);
	setTimeout(function(){
		$(".rating-box").remove();
	},200);
 }
 function feedbackSubmit(){
 	var text = $(".rating-box textarea").val();
 	if(text!=""){
 		$.mamall_request('feedback.insert', {
			customerId: getCId(),
			content:text
		}, function(r) {
			nui.toast('Thank you for your feedback!');
			localStorage.setItem("HAS_RATE_ALREADY", true);
			ratingRemove();
		},"",api);
 	}else{
		nui.toast('Please enter a comment.');
 	}
}

function gotoOurMallWeb(url) {
	if(sysType == 'ios') {
		var type = 2;
	} else {
		var type = 1;
	}
	var sysType = api.systemType;
	var jpId = localStorage.getItem("OURMALL_RGID")?localStorage.getItem("OURMALL_RGID"):"";
	var redirectUrl = hostURL() + "?m=main&a=redirectFromApp&hideH5Menu=1&hideH5MenuFromNewApp=1&mPlatform=" + type + "&jpushCode=" + jpId + "&OM_DEVICE_UUID=" + api.deviceId;
	url = redirectUrl + '&redirectUrl=' + encodeURIComponent(url);
	api.openWin({
		name: "OurMallWeb",
		url: "widget://html/product/webpage.html",
		pageParam: {_url:url},//这里是要打开的网址
		animation: {
			type: "movein",
			subType: "from_right",
			duration: 300,
		},
		reload: true,
		slidBackEnabled: true,
		delay: 0,
	});
}
function hostURL(){
    var host = '';
    var HTTP_HEADER = '';
    if(api.debug == true) {
        HTTP_HEADER = 'http';
		host = HTTP_HEADER + '://sandbox.video.ourmall.com/index.php';
    }else{
		HTTP_HEADER = 'https';
		host = HTTP_HEADER + '://video.ourmall.com/index.php';
	}
    return host;
}
function openFrameReload(index){
	api.setFrameGroupIndex({
		name: 'mallGroup',
		index: index,
		scroll: true,
		reload:true
		
	});
}
function openAccountPageFromBonusGet() {
	sendCloseBonusEvent();
//	api.openWin({
//      name: 'account',
//      url: 'widget://main.html',
//      pageParam: {"page":"account"},
//      animation: {
//          type: "movein",
//          subType: "from_right",
//          duration: 300,
//      },
//      reload: true,
//      slidBackEnabled: true,
//      delay: 0,
//  });
	getUserInfo(function(){
		api.execScript({
		    name: 'main',
		    script: 'changeFrame(document.getElementById("AppMenuAccount"),3);'
		});
	});
}
function bonusLayoutCreat(force){
	var showBonusGetStatus = localStorage.getItem("showBonusGetStatus");
	var customerHasReceiveBonus = localStorage.getItem("customerHasReceiveBonus");
	var force = force ? force : false;
	if(! customerHasReceiveBonus) {
		if((force) || (!showBonusGetStatus)) {
			var bonusLayoutHTML = '<div class="bonus-get-layout">\
			    	<div class="ad-img" onclick="openAccountPageFromBonusGet()"></div>\
			    	<a href="javascript:sendCloseBonusEvent();" class="close"><i class="iconfont icon-guanbi"></i></a>\
			    </div>\
			    <div class="bouns-mask"></div>'
			$("body").append(bonusLayoutHTML);
			api.addEventListener({
			    name: 'closeBonusMask'
			}, function(ret, err) {
			    closeBonusLayout();
			});
		} else {
			bounsSideBtnCreate();
		}

	}
}
function sendCloseBonusEvent() {
	api.sendEvent({
	    name: 'closeBonusMask',
	    extra: {
	    }
	});	
}
function  closeBonusLayout(){
	localStorage.setItem("showBonusGetStatus", true);
	$("body .bonus-get-layout,.bouns-mask").remove();
}
//创建宝箱
function bounsSideBtnCreate(){
	var bounsSideBtnHtml = '<div class="side-btn-bonus">\
						  		<a href="javascript:bonusLayoutCreat(true);" class="get-the-bonus">\
						  			<span class="gift-move"></span>\
						  			<span class="gift-shine"></span>\
						  			<span class="gift-moving"></span>\
						  		</a>\
							</div>'
	$("body").append(bounsSideBtnHtml); 	
}
//关闭宝箱
function  closeBounsSideBtn(){
	$("body .side-btn-bonus").remove();
}

function showBottomAlertGiftHtml() {
	var _innerHtml = '<div class="bottom-gift" style="display:none">\
							<div class="content">\
								<img src="../../image/gift.png">\
								<span>Enjoy  your first order,up to 20% OFF !</span>\
							</div>\
							<a href="javascript:;" class="close" tapmode>\
								<i class="iconfont icon-guanbi"></i>\
							</a>\
						</div>'
	$('body').append(_innerHtml);
	setTimeout(function(){
		$(".bottom-gift").show();
		$(".bottom-gift").addClass("active");
	},500);
	
	$(".bottom-gift .close").click(function(){
		$(".bottom-gift").remove();
		localStorage.setItem('bottomGiftClose','true');
	})
}


function bottomAlertGift(){

	if(! localStorage.getItem("customerHasReceiveBonus")=='true') { return; } //没领过bonus
	if(localStorage.getItem('bottomGiftClose')=='true'){ return; } //关闭了弹层
	
	if(getCId()) {
		$.mamall_request('customer.hasfirstorder', {
			customerId: getCId()
		}, function(r) {
			if('9999' == r.ErrorCode) {
				if(r.Data.isFirstOrder == 1) {
					return;
				} else {
					showBottomAlertGiftHtml();
				}
			}
		},"",api);
	} else {
		showBottomAlertGiftHtml();
	}
}
//全选全不选
function AllCheckbox (){
	//全选，全不 all
	$(document).on("change","[data-checkbox-all]",function(){
		var checkboxT = $(this).attr("data-checkbox-all");
		$('[data-checkbox-sub="'+checkboxT+'"]').prop("checked",this.checked);
	});
	//全选，全不 sub
	$(document).on("change","[data-checkbox-sub]",function(){
		var obj = $('[data-checkbox-sub="'+$(this).attr("data-checkbox-sub")+'"]');
		$('[data-checkbox-all="'+$(this).data("checkbox-sub")+'"]').prop("checked",obj.length === obj.filter(":checked").length ? true : false);
	});
}
//pay success
function paySuccess(){
	api.execScript({
	    name: 'main',
	    script: 'changeFrame(document.getElementById("AppMenuAccount"),3)'
	});
	api.openWin({
    	name: 'main',
    	slidBackEnabled:false,
    	animation:{
	    	type:'none'
	    }
	});
	api.closeWin({
	    name: 'order-confirm',
	    animation:{
	    	type:'none'
	    }
	});
	
}
function startPaypal(totalPrice,paymentOrderCode){
	if(typeof payMask != 'function'){
		payMask = function(){
			api.execScript({
			    name: 'main',
			    script: 'paySuccess()'
			});	
		}
	}
	var paypal = api.require('paypal');
		paypal.pay({
		     currency: 'USD',
		     price: totalPrice,
		     description: 'OurMall Order NO: ' + paymentOrderCode,
		     mode: api.debug == true ? 'sandbox' : 'production' // production  sandbox  noNetwork
		}, function(ret) {
		 	if(ret && ret.state == 'success') {
		 	    $.mamall_request('video.order.executepayment',{paymentId:ret.response.id, type:1, orderCode:paymentOrderCode}, function(r) {
		 			if('9999' == r.ErrorCode) {
		 				payMask('success');
					} else {
		 				payMask('failed');
		 			}
					setTimeout(function(){
		 					api.execScript({
							    name: 'main',
							    script: 'paySuccess()'
							});	
		 				},3250);
		 		},undefined,api);
		 	}else{
		 		payMask('failed');
		 		setTimeout(function(){
 					api.execScript({
					    name: 'main',
					    script: 'paySuccess()'
					});	
 				},2000);
		 	}
	    });
}

function startPayssion(customerId,paymentData){
	var jsonOrderCodeData = new Object; 
	var paymentData2 = new Object;
	for(var i in paymentData){
		jsonOrderCodeData[i] = new Object;
	}
	for (var j in jsonOrderCodeData){
		jsonOrderCodeData[j].goodsAmount = paymentData[j].goodsAmount
		jsonOrderCodeData[j].shippingAmount = paymentData[j].shippingAmount
		jsonOrderCodeData[j].couponAmount = paymentData[j].couponAmount
	}
	paymentData2.customerId = customerId;
	paymentData2.jsonOrderCode = JSON.stringify(jsonOrderCodeData)

	$.mamall_request('order.getpayurl',paymentData2, function(r) {
		if(r.ErrorCode == '9999') {
			var pay2Url = r.Data.payUrl;
			api.openWin({
				name: "payssion",
				url: "widget://html/product/webpage.html",
				pageParam: {_url:pay2Url},//这里是要打开的网址
				animation: {
					type: "movein",
					subType: "from_right",
					duration: 300,
				},
				reload: true,
				slidBackEnabled: false,
				delay: 0,
			});
		} else {
			nui.toast(r.Message);
			api.sendEvent({
			    name: 'cancelPay'
			});
		}
	},undefined,api);
}
