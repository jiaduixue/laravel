ARCommon = function(){
	
	
}
